<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_Model {
	public function __construct(){
		parent::__construct();
		//Do your magic here
	}
/*************************************************************************/
/************************   Login Function  *******************************/
/*************************************************************************/


	public function Login(){
		$email = $this->input->post('email');
		$pass = $this->input->post('password');
		$password = md5("Elegant@2017".$pass);

		$query = $this->db->select("*")
						  ->from("users")
						  ->where("email",$email)
						  ->where('password',$password)
						  ->get();
		if($query->num_rows()==1){
			$session = array(
				'user_name' 			=> $query->row(0)->user_name,
				"password"   			=> $query->row(0)->password,
				"email"      			=> $query->row(0)->email,
				"distribution_house"	=> $query->row(0)->distribution_house,
				"ac_team"				=> $query->row(0)->active_team,
				"service_id"			=> $query->row(0)->service_id,
				"user_role"				=> $query->row(0)->user_role,
				"user_id"		       	=> $query->row(0)->id,
				"uid"					=> $query->row(0)->user_id

			);

			$this->session->set_userdata($session);
			return TRUE;



		}else{	
			return FALSE;
		}

	}

/*************************************************************************/
/****************  Check user is Login or Not ****************************/
/*************************************************************************/

	public function CheckLogin(){
		if($this->session->userdata('user_id')==!NULL || $this->session->userdata('user_id')!= 0){
			return TRUE;
		}else{
			return FALSE;
		}
	}


/*************************************************************************/
/****************  All Users ****************************/
/*************************************************************************/


	public function CountUsers(){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where("user_role",3)
						  ->get();
		return $query->num_rows();
	}

	public function GetUsers($limit,$offset){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where("user_role",3)
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();
	}
/*************************************************************************/
/*******************************  Single User ****************************/
/*************************************************************************/

	public function GetUser($id=NULL){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where("id",$id)
						  ->get();
		return $query->result();
	}
/****************************************************************************
							Admins
*****************************************************************************/
	public function CountAdmins(){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where('user_role',2)
						  ->get();
		return $query->num_rows();
	}

	public function GetAdmins($limit,$offset){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where('user_role',2)
						  ->get();
		return $query->result();
	}
/******************************************************************************
		===================  Super Admin ==================
*******************************************************************************/
	public function CountSuperAdmin(){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where('user_role',1)
						  ->get();
		return $query->num_rows();
	}

	public function GetSuperAdmins($limit,$offset){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where('user_role',1)
						  ->get();
		return $query->result();
	}

/*************************************************************************************
								Profiling
**************************************************************************************/
	
	public function Profile($user_id=NULL){
		$query = $this->db->select("*")
						  ->from("users")
						  ->where("user_id",$user_id)
						  ->get();
		return $query->result();
	}

	public function AdminByteam($active_team = NULL){

		if($active_team == NULL || $active_team==0){

			$query = $this->db->select("*")
						  ->from("users")
						  ->where('user_role',2)
						  ->get();

		}else{

			$query = $this->db->select("*")
							  ->from("users")
							  ->where('active_team',$active_team)
							  ->where('user_role',2)
							  ->get();
		}
		return $query->result();
	}


#End Of File
}

/* End of file UserModel.php */
/* Location: ./application/models/UserModel.php */