<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardModel extends CI_Model {
	public function __construct(){
		parent::__construct();
		//Do your magic here
	}

	public function MakeRequst(){

		$id = $this->input->post('id');
		$title = $this->input->post('title');
		$team = $this->input->post('team');
		$service = $this->input->post('service');
		$products = $this->input->post('products');
		$qnt = $this->input->post('qnt');
		$argent = isset($_POST['argent']) ? $_POST['argent']:0;
		
		$remarks = $this->input->post('remarks');

		if($_FILES['image']['size']==0){
			$file = 0;
		}else{
			$file = $this->upload->data('file_name');
		}
		$mail = isset($_POST['mail']) ? $_POST['mail']:0;

		$created = date("Y-m-d");
		$time 	 = date("h:i:s A");
		$request_by = $this->session->userdata('user_id');

		$attr = array(
			"req_date"       		=> $created,
			"request_by"     		=> $request_by,
			"request_title"  		=> $title,
			"quantity"       		=> $qnt,
			"activition_team"		=> $team,
			"service_name" 			=> $service,
			"products_name"			=> $products, 
			"ticket"       			=> $id,
			"comments"     			=> $remarks,
			"file"     	   			=> $file,
			"mail"     			    => $mail,
			"urgent"			    => $argent,
			"time"					=> $time,
			'status'				=> 1
			
		);
		if($this->db->insert('request',$attr)==TRUE){
			return TRUE;
		}else{
			return FALSE;
		}

	}


	//CountMyRequets

	public function CountMyRequetsUser(){
		$acteam = $this->session->userdata('user_id');
		$query = $this->db->select("*")
						  ->from("request")
						  ->where("request_by",$acteam)
						  ->get();
		return $query->num_rows();
	}

	public function GetMyRequestUser($limit,$offset){
		$acteam = $this->session->userdata('user_id');
		$query = $this->db->select("*")
						  ->from("request")
						  ->where("request_by",$acteam)
						  ->order_by('req_id','DESC')
						  ->get();
		return $query->result();
	}

	//Status Add

	public function AddStatus(){
		$img = $this->upload->data('file_name');
		$status = $this->input->post('status');
		$type = isset($_POST['type']) ? $_POST['type']:0;

		$attr = array(
			"image"			=> $img,
			'status_name'	=> $status,
			'type'			=> $type
		);
		if($this->db->insert('status',$attr)){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	/*****************************************
		====== Admin Retrive datas ======		
	****************************************/
	public function CountAdminOpen(){
		
		$active = $this->session->userdata("ac_team");
		$query  = $this->db->select("*")
						   ->from("request")
						   ->where("activition_team",$active)
						   ->get();

		return $query->num_rows();
	}

	public function GetAdminOpenReq($limit,$offset){
		$active = $this->session->userdata("ac_team");
		$query  = $this->db->select("*")
						   ->from("request")
						   ->where("activition_team",$active)
						   ->order_by('req_id',"DESC")
						   ->limit($limit,$offset)
						   ->get();
		return $query->result();
	}


	public function DoExecute(){
		if($_FILES['image']['size']==0){
			$file = 0;
		}else{
			$file = $this->upload->data('file_name');
		}

		$exe_user = $this->session->userdata('user_id');
		$r_qnt = $this->input->post('exe_qnt');
		$status = $this->input->post('status');
		$date = date("d-M-Y h:i:s A");
		$comments = $this->input->post('comments');
		$req_id = $this->input->post('req_id');
		
		

		$query = $this->db->query("SELECT * FROM `executions` WHERE `req_id` = '$req_id' ");
		if($query->num_rows()==1){
			$r_qnt =$r_qnt+$query->row(0)->rem_qnt;
			$attr = array(
					"execution_date"	=>$date,
					"req_id"			=>$req_id,
					"exe_user"			=>$exe_user,
					"rem_qnt"			=>$r_qnt,
					"comments"			=>$comments,
					"file"				=> $file
				);

			$this->db->where('req_id',$req_id);
			if($this->db->update('executions',$attr)==TRUE){
				$this->db->where('req_id',$req_id);
				$this->db->update('request',array('status' =>$status, 'exe_user' =>$exe_user));
				return TRUE;
			}else{
				return FALSE;
			}
		}else{

			$attr = array(
					"execution_date"	=>$date,
					"req_id"			=>$req_id,
					"exe_user"			=>$exe_user,
					"rem_qnt"			=>$r_qnt,
					"comments"			=>$comments,
					"file"				=> $file
				);

			if($this->db->insert('executions',$attr)==TRUE){
				$this->db->where('req_id',$req_id);
				$this->db->update('request',array('status' =>$status, 'exe_user' =>$exe_user ));
				return TRUE;
			}else{
				return FALSE;
			}
		}

	}

	/****************************************
				Users Request By Status
	*****************************************/
	public function CountByStatusUser($status=NULL){

		$user = $this->session->userdata('user_id');

		$query = $this->db->select("*")
						  ->from("request")
						  ->where("request_by",$user)
						  ->where("status",$status)
						  ->get();
		return $query->num_rows();
	}

	public function GetRequestByStatus($limit=NULL,$offset=NULL,$status=NULL){
		$user = $this->session->userdata('user_id');
		$query = $this->db->select("*")
						  ->from("request")
						  ->where("request_by",$user)
						  ->where("status",$status)
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();
	}




	/****************************************
				Admoin Request By Status
	*****************************************/
	public function CountByStatusAdmin($status=NULL){

		$user = $this->session->userdata('user_id');

		$query = $this->db->select("*")
						  ->from("request")
						  ->where("exe_user",$user)
						  ->where("status",$status)
						  ->get();
		return $query->num_rows();
	}

	public function GetRequestByAdmin($limit=NULL,$offset=NULL,$status=NULL){
		$user = $this->session->userdata('user_id');
		$query = $this->db->select("*")
						  ->from("request")
						  ->where("exe_user",$user)
						  ->where("status",$status)
						  ->limit($limit,$offset)
						  ->get();
		return $query->result();
	}

	/****************************************
				Super Admin Request By Status
	*****************************************/
	public function CountByStatusSuper($status=NULL){

			$user = $this->session->userdata('user_id');

			$query = $this->db->select("*")
							  ->from("request")
							  
							  ->where("status",$status)
							  ->get();
			return $query->num_rows();
		}

		public function GetRequestBySuper($limit=NULL,$offset=NULL,$status=NULL){
			
			$query = $this->db->select("*")
							  ->from("request")							  
							  ->where("status",$status)
							  ->limit($limit,$offset)
							  ->get();
			return $query->result();
		}

#End Of File;
}

/* End of file DashboardModel.php */
/* Location: ./application/models/DashboardModel.php */