<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'UserController';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/***************************************************************************************
====================================== @@ User Routes @@====================================
UserLogin, User Create, User Data Update, User Delete 
***************************************************************************************/

$route['user-login'] = "UserController/Index";
$route['login'] = "UserController/Login";
$route['logout'] = "UserController/Logout";
//User Start //
$route['dashboard/users'] = "UserController/AllUsers";
$route['user/delete/(:any)'] = "UserController/UserRemove/$1"; 
$route['user/details/(:any)'] ="UserController/UserView/$1";
//Admin start
$route['dashboard/admin'] = "UserController/AllAdmins";
$route['admin/delete/(:any)'] = "UserController/AdminRemove/$1";
$route['admin/details/(:any)'] ="UserController/AdminView/$1";
//Super start
$route['dashboard/super'] = "UserController/AllSuperAdmin";
$route['super/delete/(:any)'] = "UserController/AdminRemove/$1";
$route['super/details/(:any)'] ="UserController/AdminView/$1";

//Profiling
$route['dashboard/profile/(:any)'] = "UserController/Profile/$1";
$route['dashboard/change-password'] = "UserController/ChangePassword";

//Change Password ToAlluser
$route['user/admin-change-password/(:any)'] = "UserController/AdminChangePass/$1";
/*******************************************
	@@@@@@@  Dashboard Routes @@@@@@@@@@@@

*************************************************/
$route['dashboard'] = "DashboardController";



//Activition Team
$route['dashboard/activition-team'] = "DashboardController/ActivitionTeam";
$route['settings/team/edit/(:any)'] = "DashboardController/EditTeam/$1";
$route['settings/team/delete/(:any)'] = "DashboardController/TeamDelete/$1";


//Services

$route['dashboard/settings/serviecs'] = "DashboardController/Services";
$route['dashboard/serviecs/edit/(:any)'] = "DashboardController/EditServices/$1";
$route['dashboard/serviecs/delete/(:any)'] = "DashboardController/DeleteService/$1";

//Products
$route['dashboard/settings/products'] = "DashboardController/NewProducts/$1";
$route['dashboard/settings/products/edit/(:any)'] = "DashboardController/ProEdit/$1";
$route['products/delete/(:any)'] = "DashboardController/ProDelete/$1";

//Status 
$route['dashboard/settings/status'] = "DashboardController/RequestStatus";
$route['status/remove-status/(:any)'] ="DashboardController/RemoveStatus/$1";

//distribution House
$route['dashboard/settings/distribution-house'] = "DashboardController/DistributionHouse";
$route['settings/dis-delete/(:any)'] = "DashboardController/DeleteDistributionHouse/$1";
//RequetsNew users
$route['dashboard/new-request'] = "DashboardController/NewRequest";
$route['dashboard/my-request'] = "DashboardController/MyRequestUser";
$route['dashboard/my-request/(:any)'] = "DashboardController/MyRequestUser/$1";
$route['dashboard/view-request/(:any)'] = "DashboardController/ViewRequest/$1";

$route['download-file/(:any)'] = "DashboardController/DownloadFile/$1";
$route['dashboard/user-search'] = "DashboardController/UserSearch";

$route['dashboard/view/by-status/(:any)'] = "DashboardController/ViewByStatus/$1";
$route['dashboard/view/by-status/(:any)/(:any)'] = "DashboardController/ViewByStatus/$1/$1";
//Admin Request
$route['dashboard/admin-open-request'] = "DashboardController/AdminOpenRequest";
$route['dashboard/admin-search'] = "DashboardController/AdminSearch";
$route['dashboard/view-admin/by-status/(:any)'] = "DashboardController/ViewByStatusAdmin/$1";



//Super Admin REquest
$route['dashboard/super-admin-search'] = "DashboardController/SuperSearch";
$route['dashbboard/view-super/by-status'] = "DashboardController/ViewBSuper";
$route['dashbboard/view-super/by-status/(:any)'] = "DashboardController/ViewBSuper/$1";
