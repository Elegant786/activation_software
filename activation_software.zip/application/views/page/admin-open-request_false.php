<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Request</h5>
                                        <h6 class="sub-heading">View Request</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row gutters">
                        
                        

                        <div class="col-md-12">
                            <div class="card">
                              <div class="card-header">Request Data </div>
                                <div class="card-body">
                                    <div class="col-md-6">
                                        <?php
                                            $id = $this->uri->segment(3);
                                            $query = $this->db->query("SELECT * FROM `request` WHERE `req_id` = '$id' ");
                                            $result = $query->result();
                                            foreach($result AS $request){
                                        ?>

                                        <table class="table table-resposive">
                                            <tr>
                                                <td width="50%">Traking#: <input type='text' disabled="disabled" class="form-control" value="<?php echo $request->ticket?>"></td>
                                                <td>Activition Team: <?php
                                                        $act = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` = '$request->activition_team' ");
                                                        if($act->num_rows() >0){
                                                            echo $act->row(0)->team_name;
                                                        }
                                                ?></td>
                                            </tr>
                                            <tr>
                                                <td width="50%">Requested By: <?php
                                                        $rq_by = $this->db->query("SELECT * FROM `users` WHERE `id` = '$request->request_by' ");
                                                        if($rq_by->num_rows() >0){
                                                            echo $rq_by->row(0)->user_name;
                                                        }?>
                                                    
                                                </td>
                                                <td>Requested Date: <?php echo date("d-M-Y h:i:s A",strtotime($request->req_date.$request->time))?></td>
                                            </tr>
                                            <tr>
                                                <td width="50%">Service Information:
                                                    <?php
                                                        $service = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$request->service_name' ");
                                                        if($service->num_rows() >0){
                                                            echo $service->row(0)->service_name;
                                                        }
                                                    ?>

                                                </td>
                                                <td>Products Name: 

                                                    <?php
                                                        $products = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$request->products_name' ");
                                                        if($products->num_rows() >0){
                                                            echo $products->row(0)->pro_name;
                                                        }
                                                    ?>

                                                </td>
                                            </tr>

                                            <tr>
                                                <td width="50%">Quantity: <?php echo $request->quantity?></td>
                                                <td>Remarks: <p><?php echo $request->comments?></p></td>
                                            </tr>

                                             <tr>
                                                <td colspan="2">Status: <?php

                                                    $status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$request->status' ");
                                                    if($status->num_rows()>0){
                                                        echo $status->row(0)->status_name;
                                                    }

                                                ?></td>
                                                
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <?php if($request->file!=0){?>
                                                    <a href="<?php echo base_url()?>/download-file/<?php echo $request->file;?>" target="_blank"><?php echo $request->file;?></a>
                                                    <?php }else{?>
                                                        No File Included
                                                    <?php }?>
                                                </td>
                                            </tr>
                                        </table>
                                        

                                        <div class="execution">
                                            <div class="title">Execution Details</h6>
                                                <?php
                                                    $execution = $this->db->query("SELECT * FROM `executions` WHERE `req_id` = '$request->ticket' ");
                                                    $exe_result = $execution->result();
                                                    foreach($exe_result AS $exe){
                                                ?>
                                                    <table class="table table-responsive">
                                                        <tr>
                                                            <td><?php 
                                                                $ex_user = $this->db->query("SELECT * FROM `users` WHERE `id` = '$exe->exe_user' ");
                                                                if($ex_user->num_rows()>0){
                                                                    echo $ex_user->row(0)->user_name;
                                                                }
                                                            ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <p>Remaning Quantity: <?php echo $request->quantity-$exe->rem_qnt;?> </p>
                                                            </td>
                                                            <td>
                                                                <p>Execution Quantity: <?php echo $exe->rem_qnt;?> </p>
                                                            </td>


                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                Executor Comments: <p>
                                                                    <?php echo $exe->comments?>
                                                                </p>
                                                            </td>
                                                        </tr>

                                                    </table>



                                                <?php }?>
                                        </div>
                                        <?php }?>
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>