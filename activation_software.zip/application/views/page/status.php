<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Services</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row gutters">
                       
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">Add Status</div>
                                <div class="card-body">
                                    <?php echo form_open_multipart("DashboardController/AddStatus")?>
                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <input name="status" required="required" class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label for="img"></label>
                                            <input type="file" name="image">
                                        </div>
                                        <div class="form-group">
                                        <label><input type="checkbox" name="type" value="1"> &nbsp Open <span ><a href="#">?</a></span></label>
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-success">Submit</button>
                                        </div>
                                    <?php echo form_close()?>
                                </div>
                            </div>
                        </div>


                        <div class=" col-sm-offset-2 col-md-4">
                            <div class="card">
                                <div class="card-header">Status</div>
                                <div class="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <td width="10">S/N</td>
                                                <td>status</td>
                                                <td>Color</td>
                                                <td>Action</td>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php 
                                                $query = $this->db->get("status");
                                                $result = $query->result();
                                                foreach($result AS $row){
                                                    @$sl++;
                                            ?>
                                            <tr>
                                                <td><?php echo $sl;?></td>
                                                <td><?php echo $row->status_name;?></td>
                                                <td class="text-center">
                                                    <?php echo "<img class='img-circle circlediv' height='20' width='20' src='".base_url()."uploads/request/".$row->image."'";?>
                                                </td>
                                                <td class="text-center"><a href="<?php echo base_url()?>status/remove-status/<?php echo $row->sta_id?>" class="btn btn-link"><i class="fa fa-trash"></i></a></td>
                                            </tr>
                                            <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
</div>