<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Activition Team</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row">
                        <div class="col-md-12">
                               <?php
                                    /****** Team Insert Start ******/
                                        if(isset($_POST['add_new'])){
                                            $team = $this->input->post('team');
                                            $team = ucfirst($team);
                                            if($this->db->insert('activition_team',array('team_name' => $team)) == TRUE){
                                                echo "<div class='alert alert-success'> New Team Added</div>";
                                            }else{
                                                echo "<div class='alert alert-danger'> Team can not be added in database</div>";
                                            }
                                        }


                                        /*************** Update Activition Team ****************/

                                        if(isset($_POST['update'])){
                                            $team = $this->input->post('team');
                                            $team = ucfirst($team);
                                            $id = $this->input->post('id');
                                            $this->db->where('team_id',$id);
                                            if($this->db->update('activition_team',array('team_name' => $team))==TRUE){
                                               redirect('dashboard/activition-team?action=success','refresh');
                                            }else{
                                                echo "<div class='alert alert-danger'> Team can not be Update</div>";
                                            }

                                        }
                               ?> 
                        </div>
                    </div>

                    <div class="row">
                       <?php
                            if($this->uri->segment(4)){
                       ?>
                            <!-- *******************Team Update Form ******************* -->
                             <div class="col-md-6">
                                <?php echo form_open()?>
                                        <div class="card">
                                            <div class="card-header">Add new Activition Team</div>
                                            <div class="card-body">
                                            <?php
                                                $id = $this->uri->segment(4);
                                                $query = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` = '$id' ");
                                                $result = $query->result();
                                                foreach($result AS $row){
                                            ?>

                                                <div class="form-group">
                                                    <label for="team">Team name</label>
                                                    <input id="team" value="<?php echo $row->team_name?>" type="text" required="required" name="team" class="form-control">
                                                </div>
                                                <input type="hidden" name="id" value="<?php echo $row->team_id?>">
                                            <?php }?>
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-success" name="update"> Update Team</button>
                                                </div>
                                            </div>
                                        </div>
                                       </div>
                                <?php echo form_close()?>
                        <!-- ******************* Team Update Form End ******************* -->
                       <?php }else{?>
                    <!-- ******************* Add new Section start ******************* -->
                                
                                <div class="col-md-6">
                                    <?php echo form_open()?>
                                    <div class="card">
                                        <div class="card-header">Add new Activition Team</div>
                                        <div class="card-body">

                                            <div class="form-group">
                                                <label for="team">Team name</label>
                                                <input id="team" type="text" required="required" name="team" class="form-control">
                                            </div>


                                            <div class="form-group">
                                                <button type="submit" class="btn btn-success" name="add_new"> Add Team</button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php echo form_close()?>
                                </div>

                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">All Teams</div>
                                        <div class="card-body">
                                            <table class="table table-bordered table-responsive">
                                                <thead>
                                                    <tr>
                                                        <td>S/N</td>
                                                        <td>Team Name</td>
                                                        <td>Action</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = $this->db->get('activition_team');
                                                    $result = $query->result();
                                                    foreach($result AS $row){
                                                    @$sl++;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $sl;?></td>
                                                        <td><?php echo $row->team_name?></td>
                                                        <td>
                                                            
<div class="dropdown">
    <a class="btn btn-warning btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Action
    </a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
        <a class="dropdown-item" href="<?php echo base_url()?>settings/team/edit/<?php echo $row->team_id?>">Edit</a>
        <a onclick="return confirm('Are you sure want to delete <?php echo $row->team_name?> ?')" class="dropdown-item" href="<?php echo base_url()?>settings/team/delete/<?php echo $row->team_id?>">Delete</a>
    </div>
</div>


                                                        </td>
                                                    </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                    <!-- ******************* Add new section End ******************* -->
                    <?php }?>
                </div>
</div>