<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">My Request</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
											<i class="icon-download4"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					</header>
					<!-- END: .main-heading -->
					<!-- BEGIN .main-content -->
				<div class="main-content">
						<!-- Row start -->
						<div class="row gutters">
							<div class="col-md-12">
								<div class="card">
									<div class="card-header">Recent Tickets Status</div>
									<div class="card-body">
										<table class="table table-bordered table-responsive">
											<thead>
												<tr>
													<td>Request Date</td>
													<td>Ticket #</td>
													<td>Service Name</td>
													<td>Products Name</td>
													<td>Urgent</td>
													<td>Status</td>
													
													<td>Assigned User</td>
													<td>Alarm</td>
													<td>Action</td>
												</tr>
											</thead>

											<tbody>
												<?php
													if(isset($request)){
														foreach($request AS $row){

												?>
												<tr>
													<td><?php echo date('d-M-Y h:i:s A',strtotime($row->req_date.$row->time))?></td>
													<td><?php echo $row->ticket?></td>
													<td><?php 
														$service = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$row->service_name' "); 
														if($service->num_rows() >0){
															echo $service->row(0)->service_name;
														}
													?></td>
													<td><?php
															$pro = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$row->products_name' "); 
														if($pro->num_rows() >0){
															echo $pro->row(0)->pro_name;
														}
														?>
													</td>
													<td>
														<?php
															if($row->urgent == 1){
																echo "Yes";
															}else{
																echo "No";
															}
														?>
													</td>
													<td>
														<?php
															$status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
															if($status->num_rows()>0){
																echo $status->row(0)->status_name;
															}
														?>
													</td>													
													<td>
														<?php 
														$Asuser = $this->db->query("SELECT * FROM `executions` WHERE `req_id` ='$row->req_id' ");
                                                        if($Asuser->num_rows()>0){
                                                            $user = $Asuser->row(0)->exe_user;
                                                            $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$user' ");
                                                            if($uQuery->num_rows()==1){
                                                                echo $uQuery->row(0)->user_name;
                                                            }
                                                        }

													?>
													</td>
													<td class="text-center"><?php
															$status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
															if($status->num_rows()>0){
																echo "<img class='img-circle circlediv' height='20' width='20' src='".base_url()."uploads/request/".$status->row(0)->image."'>";
															}
														?></td>
														<td><a class="btn btn-success btn-sm" href="<?php echo base_url()?>dashboard/view-request/<?php echo $row->req_id;?>">View Details</a></td>
												</tr>
												<?php } }?>
											</tbody>
										</table>

									</div>
								</div>
							</div>
						</div>
					<!-- END: .main-content -->
				</div>