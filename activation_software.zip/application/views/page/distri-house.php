<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Distribution House Settings</h5>
                                        <h6 class="sub-heading">Create Distribution House</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                                <?php if(isset($_POST['disname'])){
                                    $disname = $this->input->post('disname');
                                    $query = $this->db->query("SELECT * FROM `distributuion` WHERE `dis_name` = '$disname' ");
                                    if($query->num_rows()==0){
                                        if($this->db->insert('distributuion',array('dis_name' => $disname)) == TRUE ){
                                            echo "<div class='row'><div class='col-md-12'> <div class='alert bg-success'> New Distribution Name added </div> </div></div>";
                                        }else{
                                             echo "<div class='row'><div class='col-md-12'> <div class='alert bg-danger'>Error !! </div> </div></div>";
                                        }
                                    }else{
                                         echo "<div class='row'><div class='col-md-12'> <div class='alert bg-warning'> Alerady Exist</div> </div></div>";
                                    }

                                }?>
                                                    
                           

                    <div class="row gutters">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Add New</div>
                                <div class="card-body">
                                        <?php echo form_open()?>
                                                <div class="form-group">
                                                    <label>Distribution Name</label>
                                                    <input type="text" name="disname" class="form-control">
                                                </div>

                                                <div class="form-group">
                                                    <button class="btn btn-success" type="submit" name="Create"> Create</button>
                                                </div>
                                        <?php echo form_close()?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Add New</div>
                                <div class="card-body">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th width="20">S/N</th>
                                                    <th>Distribution Name</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php
                                                 //Retrive for Distribution Table
                                                    $dis = $this->db->get('distributuion');
                                                    $result = $dis->result();
                                                   
                                                    foreach($result AS $row){
                                                        @$sl++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $sl;?></td>
                                                    <td><?php echo $row->dis_name?></td>
                                                    <td>
                                                        <a onclick="return confirm('Are You Sure ? want to delete <?php echo $row->dis_name?> ?')" href="<?php echo base_url()?>settings/dis-delete/<?php echo $row->dis_id?>" class='btn btn-xs btn-warning'>Delete</a>
                                                    </td>
                                                </tr>
                                                    <?php }?>
                                            </tbody>
                                        </table>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
</div>