<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-cogs"></i>
                    </div>
                    <div class="page-title">
                        <h5>Settings</h5>
                        <h6 class="sub-heading">Services</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

<div class="main-content">
   
    <?php if(!isset($_POST['submit'])){?>
    <div class="row gutters">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Admin Search</div>
                <div class="card-body">
                    <?php echo form_open()?>
                        <table class="table table-bordered">
                            <tr>
                                <td>Request Date From</td>
                                <td><input name="date1" class="form-control" type="date"></td>
                                <td>Request Date To</td>
                                <td><input name="date2" class="form-control" type="date"></td>
                            </tr>
                            <tr>
                                <td>Servie name</td>
                                <td>
                                    <select onchange="GetProducts(this.value)" name="service" class="form-control">
                                        <option value="0">Please Select...</option>
                                        <?php 
                                            
                                            $query = $this->db->query("SELECT * FROM `services`");
                                            $teamResult = $query->result();
                                            foreach($teamResult AS $team){
                                        ?>
                                            <option value="<?php echo $team->ser_id?>"> <?php echo $team->service_name?></option>
                                        <?php }?>
                                     </select>
                                </td>
                                <td>Products name:</td>
                                <td>
                                    <select name="pro" class="form-control" id="products">
                                        <option value='0'>Please Select...</option>
                                     </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Ticket Status:</td>
                                <td>
                                    <select name="status" class="form-control">
                                        <option value="0"> please Select... </option>
                                        <?php
                                            $status = $this->db->query("SELECT * FROM `status` ");
                                            $sta = $status->result();
                                            foreach($sta AS $req_sta){
                                        ?>
                                        <option value="<?php echo $req_sta->sta_id?>"><?php echo $req_sta->status_name;?></option>
                                        <?php }?>
                                    </select>
                                </td>
                                <td>Urgent:</td>
                                <td>
                                    <select name="urgent" class="form-control">
                                            <option value="">Please Select...</option>
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Ticket #:</td>
                                <td><input type="text" name="ticket" class="form-control"></td>
                                <td colspan="2"></td>
                            </tr>

                            <tr>
                                <td colspan="4"><button name="submit" class="btn btn-success" name="submit"> Search </button></td>
                            </tr>
                        </table>

                    <?php echo form_close()?>

                </div>
            </div>
        </div>
    </div>
    <?php }?>
            <?php
                //Seacrch Result Start
                if(isset($_POST['submit'])){
            ?>
    <div class="row gutters">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Admin Search</div>
                <div class="card-body">
                    <?php echo form_open()?>
                        <table class="table table-bordered">
                            <tr>
                                <td>Request Date From</td>
                                <td><input name="date1" class="form-control" value='<?php if(!empty($_POST['date1'])){ echo $_POST['date1']; }?>' type="date"></td>
                                <td>Request Date To</td>
                                <td><input name="date2" class="form-control" value='<?php if(!empty($_POST['date2'])){ echo $_POST['date2']; }?>' type="date"></td>
                            </tr>
							
                            <tr>
                                <td>Servie name</td>
                                <td>
                                    <select onchange="GetProducts(this.value)" name="service" class="form-control">
                                      <?php
										if(isset($_POST['service']) && $_POST['service']!=0){											
                                            $query = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '".$_POST['service']."' ");
                                            $teamResult = $query->result();
                                            foreach($teamResult AS $team){
                                        ?>
                                            <option value='<?php echo $team->ser_id?>'> <?php echo $team->service_name?></option>
                                        <?php }
											$query2 = $this->db->query("SELECT * FROM `services` WHERE `ser_id` != '".$_POST['service']."' ");
                                            $teamResult2 = $query2->result();
                                            foreach($teamResult2 AS $team2){
												echo "<option value='$team2->ser_id'>$team2->service_name</option>";
											}

										}else{
											echo "<option value='0'>Please Select...</option>";
											$query = $this->db->query("SELECT * FROM `services`  ");
                                            $teamResult = $query->result();
                                            foreach($teamResult AS $team){
												echo "<option value='$team->ser_id'>$team->service_name</option>";
										?>
										
										
										<?php } }?>
										
										
                                     </select>
                                </td>
                                <td>Products name:</td>
                                <td>
									<?php 
										if(isset($_POST['service']) && $_POST['service']==0){
									?>
										<select name="pro" class="form-control" id="products">
											<option value='0'>Please Select..</option>
										 </select>
									<?php }elseif((isset($_POST['service']) && $_POST['service']!=0) && (isset($_POST['pro']) && !empty($_POST['pro']))  ){?>
										<select name="pro" class="form-control" >
											<?php 
												$proSearch1 = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '".$_POST['pro']."'  ");
												$prResult1 = $proSearch1->result();
												foreach($prResult1 AS $row1){
													echo "<option value='$row1->pro_id'>$row1->pro_name</option>";
												}
												
												$proSearch2 = $this->db->query("SELECT * FROM `products` WHERE `pro_id` != '".$_POST['pro']."' AND `ser_id` = '".$_POST[
'service']."'  ");											
													$Proresult = $proSearch2->result();
													
													foreach($Proresult AS $pro){
														echo "<option value='".$pro->pro_id."'>".$pro->pro_name."</option>";
													}
											?>
											
										 </select>
									<?php }
									
									elseif(isset($_POST['service']) && $_POST['service']!=0 && isset($_POST['pro']) && $_POST['pro']==0){
									?>
										 <select name="pro" class="form-control">
												<option value='0'>Please Select...</option>
												<?php
													$proSearch2 = $this->db->query("SELECT * FROM `products` WHERE  `ser_id` = '".$_POST[
'service']."'  ");												
													$Proresult = $proSearch2->result();
													foreach($Proresult AS $pro){
														echo "<option value='".$pro->pro_id."'>".$pro->pro_name."</option>";
													}
												?>
										 </select>
									<?php }?>
                                </td>
                            </tr>

                            <tr>
                                <td>Ticket Status:</td>
                                <td>
								<?php
									if(isset($_POST['status']) && $_POST['status']==0){								?>
                                    <select name="status" class="form-control">
                                        
										<option value="0"> please Select... </option>
										
										
                                        <?php
                                            $status = $this->db->query("SELECT * FROM `status` ");
                                            $sta = $status->result();
                                            foreach($sta AS $req_sta){
                                        ?>
                                        <option value="<?php echo $req_sta->sta_id?>"><?php echo $req_sta->status_name;?></option>
                                        <?php }?>
                                    </select>
									<?php }elseif(isset($_POST['status']) && $_POST['status']!=0){?>
									<select name="status" class="form-control">
										<?php
                                            $status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '".$_POST['status']."' ");
                                            $sta = $status->result();
                                            foreach($sta AS $req_sta){
                                        ?>
                                        <option value="<?php echo $req_sta->sta_id?>"><?php echo $req_sta->status_name;?></option>
                                        <?php } 
											$status2 = $this->db->query("SELECT * FROM `status` WHERE `sta_id` != '".$_POST['status']."' ");
                                            $sta2 = $status2->result();
                                            foreach($sta2 AS $req_sta2){
										?>
										<option value="<?php echo $req_sta2->sta_id?>"><?php echo $req_sta2->status_name;?></option>
										
											<?php }?>
										</select>	
										<?php }?>
										
                                </td>
                                <td>Urgent:</td>
                                <td>
                                    <select name="urgent" class="form-control">
										<?php
											if(isset($_POST['urgent']) && $_POST['urgent']==""){
										?>
									
                                            <option value="">Please Select...</option>
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
										<?php }elseif(isset($_POST['urgent']) && $_POST['urgent']==1){?>
											 <option value="1">Yes</option>
                                             <option value="0">No</option>
										<?php }elseif(isset($_POST['urgent']) && $_POST['urgent']==0){?>
											<option value="0">No</option>
											 <option value="1">Yes</option>
									<?php }?>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>Ticket #:</td>
                                <td><input type="text" value='<?php if(isset($_POST['ticket'])){ echo $_POST['ticket']; }?>' name="ticket" class="form-control"></td>
                                <td colspan="2"></td>
                            </tr>

                            <tr>
                                <td colspan="4"><button name="submit" class="btn btn-success" name="submit"> Search </button></td>
                            </tr>
                        </table>

                    <?php echo form_close()?>

                </div>
            </div>
        </div>
    </div>


        <div class="row gutters">
            <div class=col-md-12>
                <div class="card">
                     <div class="card-header">Admin Search</div>
                        <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Request Date</th>
                                            <th>Ticket #</th>
                                            <th>Service Name</th>
                                            <th>Products Name</th>
                                            <th>Urgent</th>
                                            <th>Status</th>
                                            
                                            <th>Assigned User</th>
                                            <th>Alarm</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
<?php 
$start = $this->input->post('date1');
$end = $this->input->post('date2');
$service = $this->input->post('service');
$pro = $this->input->post('pro');
$status = $this->input->post('status');
$urgent = $this->input->post('urgent');
$ticket = $this->input->post('ticket');

$sql = "SELECT * FROM `request` ";
if(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']!=0 && $_POST['urgent']!=NULL){
	$sql.="WHERE `req_date` BETWEEN '$start' AND '$end' AND  `service_name` = '$service' AND `products_name` = '$pro' AND `status` = '$status' AND `urgent` = '$urgent'  ORDER BY `req_id` DESC ";
}
elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']!=0 && $_POST['urgent']==""){
	$sql.="WHERE `req_date` BETWEEN '$start' AND '$end' AND  `service_name` = '$service' AND `products_name` = '$pro' AND `status` = '$status'  ORDER BY `req_id` DESC ";
}
elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']==0 && $_POST['urgent']==""){
	$sql.="WHERE `req_date` BETWEEN '$start' AND '$end' AND  `service_name` = '$service' AND `products_name` = '$pro'  ORDER BY `req_id` DESC ";
}

elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']==0 && $_POST['status']==0 && $_POST['urgent']==NULL){
	$sql.="WHERE `req_date` BETWEEN '$start' AND '$end' AND  `service_name` = '$service'  ORDER BY `req_id` DESC ";
}

elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['service']==0 && $_POST['pro']==0 && $_POST['status']==0 && $_POST['urgent']==NULL){
	$sql.="WHERE `req_date` BETWEEN '$start' AND '$end' ORDER BY `req_id` DESC ";
}
elseif(!empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']==0 && $_POST['pro']==0 && $_POST['status']==0 && $_POST['urgent']==NULL){
	$sql.="WHERE `req_date` = '$start'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']==0 && $_POST['urgent']==NULL){
	$sql.="WHERE `service_name` = '$service' AND `products_name` = '$pro'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']==0 && $_POST['status']==0 && $_POST['urgent']==NULL){
	$sql.="WHERE  `service_name` = '$service' ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']==0 && $_POST['status']!=0 && $_POST['urgent']==NULL){
	$sql.="WHERE  `service_name` = '$service' AND `status` = '$status' ORDER BY `req_id` DESC ";
}
elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']==0 && $_POST['status']!=0 && $_POST['urgent']!=NULL){
	$sql.="WHERE  `service_name` = '$service' AND `status` = '$status' AND `urgent` = '$urgent'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']==0 && $_POST['urgent']!=NULL){
	$sql.="WHERE `service_name` = '$service' AND `products_name` = '$pro' AND `urgent` = '$urgent'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']!=0 && $_POST['urgent']==NULL){
	$sql.="WHERE `service_name` = '$service' AND `products_name` = '$pro' AND `status` = '$status'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']!=0 && $_POST['urgent']!=NULL){
	$sql.="WHERE `service_name` = '$service' AND `products_name` = '$pro' AND `status` = '$status' AND `urgent` = '$urgent'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']==0 && $_POST['status']!=0 && $_POST['urgent']!=NULL){
	$sql.="WHERE  `service_name` = '$service' AND `status` = '$status' AND `urgent` = '$urgent'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']==0 && $_POST['status']!=0 && $_POST['urgent']!=NULL){
	$sql.="WHERE  `service_name` = '$service' AND `status` = '$status' AND `urgent` = '$urgent'  ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']==0 && $_POST['pro']==0 && $_POST['status']!=0 && $_POST['urgent']==NULL){
	$sql.="WHERE `status` = '$status'   ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']==0 && $_POST['pro']==0 && $_POST['status']!=0 && $_POST['urgent']!=NULL){
	$sql.="WHERE `status` = '$status' AND `urgent` = '$urgent'   ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']==0 && $_POST['pro']==0 && $_POST['status']==0 && $_POST['urgent']!=NULL){
	$sql.="WHERE  `urgent` = '$urgent'   ORDER BY `req_id` DESC ";
}

elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['service']==0 && $_POST['pro']==0 && $_POST['status']==0 && $_POST['urgent']!=NULL){
	$sql.="WHERE `req_date` BETWEEN '$start' AND '$end' AND `urgent` = '$urgent'   ORDER BY `req_id` DESC ";
}

elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']!=0 && $_POST['status']==0 && $_POST['urgent']!=NULL){
	$sql.="WHERE `req_date` BETWEEN '$start' AND '$end' AND `service_name` = '$service' AND `products_name` = '$pro'   ORDER BY `req_id` DESC ";
}

elseif(empty($_POST['date1']) && empty($_POST['date2']) && $_POST['service']!=0 && $_POST['pro']==0 && $_POST['status']==0 && $_POST['urgent']!=NULL){
	$sql.="WHERE  `service_name` = '$service' AND  `urgent` = '$urgent'  ORDER BY `req_id` DESC ";
}
elseif(!empty($_POST['ticket'])){
	$sql.= "WHERE `ticket` = '$ticket' ";
}

$query = $this->db->query($sql);
$result = $query->result();
foreach($result AS $row){
?>
                                       <tr>
                                                    <td><?php echo date('d-M-Y h:i:s A',strtotime($row->req_date.$row->time))?></td>
                                                    <td><?php echo $row->ticket?></td>
                                                    <td><?php 
                                                        $service = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$row->service_name' "); 
                                                        if($service->num_rows() >0){
                                                            echo $service->row(0)->service_name;
                                                        }
                                                    ?></td>
                                                    <td><?php
                                                            $pro = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$row->products_name' "); 
                                                        if($pro->num_rows() >0){
                                                            echo $pro->row(0)->pro_name;
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                            if($row->urgent == 1){
                                                                echo "Yes";
                                                            }else{
                                                                echo "No";
                                                            }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                            $status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
                                                            if($status->num_rows()>0){
                                                                echo $status->row(0)->status_name;
                                                            }
                                                        ?>
                                                    </td>                                                   
                                                    <td><?php

                                                        $Asuser = $this->db->query("SELECT * FROM `executions` WHERE `req_id` ='$row->req_id' ");
                                                        if($Asuser->num_rows()>0){
                                                            $user = $Asuser->row(0)->exe_user;
                                                            $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$user' ");
                                                            if($uQuery->num_rows()==1){
                                                                echo $uQuery->row(0)->user_name;
                                                            }
                                                        }

                                                    ?></td>
                                                    <td class="text-center"><?php
                                                            $status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
                                                            if($status->num_rows()>0){
                                                                echo "<img class='img-circle circlediv' height='20' width='20' src='".base_url()."uploads/request/".$status->row(0)->image."'";
                                                            }
                                                        ?>
                                                            
                                                    </td>
                                                        <td><a class="btn btn-success btn-sm" href="<?php echo base_url()?>dashboard/view-request/<?php echo $row->req_id;?>">View Details</a></td>
                                                </tr>
                                        <?php }?>
                                    </tbody>

                                </table>
                       



                        </div>
                    </div>
                </div>
            </div>

        <?php }//Search Result End ?>
</div>
</div>

<script type="text/javascript">
    function GetProducts(str){
        
        if (str.length == 0) { 
                document.getElementById("products").style.display="none";
                return;
            } else {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        var responseReq = this.responseText;
                        if(responseReq == "TRUE"){

                        }else{
                            document.getElementById("products").innerHTML = this.responseText;                            
                        }
                    }
                };
                xmlhttp.open("GET", "<?php echo base_url()?>DashboardController/GetProducts/"+str, true);
                xmlhttp.send();
            }
        }
</script>