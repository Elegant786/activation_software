<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Users Management</h5>
                                        <h6 class="sub-heading">Admins</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#"  class="btn btn-primary float-right" data-toggle="modal" data-target="#myModal" title="All New User">
                                            <i class="icon-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row">
                        <div class="col-md-12">
                            <?php
                                
                                /********************** user Insert **************************/  

                                if(isset($_POST['save'])){

                                    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]');

                                    $this->form_validation->set_rules('password', 'Password', 'required');
                                     $this->form_validation->set_rules("cpass","Confirm Password",'required|matches[password]');   
                                    if($this->form_validation->run()==TRUE){

                                        $name = $this->input->post('name');
                                        $user_id = $this->input->post('user_id');
                                        $ac_team = $this->input->post('ac_team');
                                        $email = $this->input->post('email');
                                        $password = md5("Elegant@2017".$this->input->post('password'));
                                        $cpass = $this->input->post('cpass');
                                        
                                        $attr = array(
                                            "user_name"             =>$name,
                                            "password"              =>$password,
                                            "created_date"          =>date("Y-m-d"),
                                            "user_id"               =>$user_id,
                                            "email"                 =>$email,
                                            "active_team"           =>$ac_team,
                                            "user_role"             =>2
                                        );
                                        if($this->db->insert('users',$attr)==TRUE){
                                            redirect('dashboard/admin?action=success','refresh');
                                        }else{
                                            echo "<div class='alert bg-danger font-white text-center'> User Not Added </div>";

                                        }

                                    }else{
                                        echo "<div class='alert bg-danger font-white text-center'>".validation_errors()."</div>";
                                    }

                              }
                              if(isset($_GET['action'])){
                                            echo "<div class='alert bg-success font-white text-center'>User Added</div>";

                              }
                            ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">All Users</div>
                                <div class="card-body">
                                        <table class="table table-bordered table-responsive">
                                            <thead>
                                                <tr>
                                                    <td width="40">UserId</td>
                                                    <td>User Name</td>                                                    
                                                    <td>Email</td>                                                    
                                                    <td>Role</td>
                                                    <td>Action</td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    if(isset($users)){
                                                        foreach($users AS $row){
                                                ?>
                                                <tr>
                                                    <td><?php echo $row->user_id?></td>
                                                    <td><?php echo $row->user_name?></td>
                                                    
                                                    <td><?php echo date('d-m-Y',strtotime($row->created_date))?></td>
                                                    
                                                    <td>Super Admin</td>
                                                    <td>
                                                        
                                                        <div class="dropdown">
                                                              <a class="btn btn-warning dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                Action
                                                              </a>
                                                              <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                                <a class="dropdown-item" href="<?php echo base_url()?>admin/details/<?php echo $row->id?>">Edit</a>

                                                                <a onclick="return confirm('Are you sure want to delete <?php echo $row->user_name?> ?')" class="dropdown-item" href="<?php echo base_url()?>super/delete/<?php echo $row->id?>">Delete</a>
                                                              </div>
                                                        </div>



                                                    </td>
                                                </tr>
                                                <?php } ?>
                                                <tr>
                                                    <td colspan="6"><?php echo $this->pagination->create_links()?></td>
                                                </tr>
                                                <?php }?>
                                            </tbody>
                                        </table>
                                </div>
                            </div>
                        </div>

                         <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <?php echo form_open()?>
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Add User As Admin</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" required="required" name="name" class="form-control" placeholder="Enter Your Name">
                                        <?php
                                            $query = $this->db->get('users');
                                            if($query->num_rows()>=0){
                                        ?>    
                                        <input type="hidden" required="required" name="user_id" value="<?php echo date("Ym").$query->num_rows()?>">
                                        <?php }?>
                                    </div>
                                        
                                    <div class="form-group">
                                        <label>Activition Team</label><br>
                                        <select  class="form-control" name="ac_team">
                                            <option value="0"> Select one</option>
                                            <?php 
                                                $query = $this->db->get('activition_team');
                                                $result = $query->result();
                                                foreach($result AS $row){
                                            ?>

                                            <option value="<?php echo $row->team_id?>"><?php echo $row->team_name?></option>
                                            <?php }?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" required="required" name="email" class="form-control" placeholder="Enter Your Email">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="text" required="required" name="password" class="form-control" placeholder="Enter Your Password">
                                    </div>

                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <input type="text" required="required" name="cpass" class="form-control" placeholder="Confirm Password">
                                    </div>
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" name="save" class="btn btn-primary">Save</button>
                                </div>
                                <?php echo form_close()?>
                            </div>
                        </div>
                    </div>
                    </div>
               
                </div>
</div>