<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Request</h5>
                                        <h6 class="sub-heading">Search</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row gutters">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">User Search</div>
                                <div class="card-body">
                                    <?php $attr = array("class"=> 'form-horizental'); echo form_open()?>
                                         <table class="table table-responsive">
                                             <tr>
                                                 <td>Request Date Form</td>
                                                 <td><input name="date1" class="form-control" type="date"></td>
                                                 <td>Request Date To</td>
                                                 <td><input name="date2" class="form-control" type="date"></td>
                                             </tr>

                                             <tr>
                                                 <td>Ticket Status</td>
                                                 <td>
                                                    <select name="status" class="form-control">
                                                        <option value="0">Please Select...</option>
                                                     <?php
                                                        $query = $this->db->get('status');
                                                        $result = $query->result();
                                                        foreach($result AS $row){
                                                     ?>
                                                        <option value="<?php echo $row->sta_id?>"> <?php echo $row->status_name?></option>
                                                     <?php }?>
                                                 </select>
                                                 </td>
                                                 <td>Ticket #</td>
                                                 <td><input type="text" name="ticket" class="form-control" value=""></td>
                                             </tr>
                                             <tr>
                                                 <td colspan="4">
                                                    <button name="search" class="btn btn-default" type="search"> Search</button>
                                                    <input value="Reset" class="btn btn-default" type="reset">
                                                </td>
                                                
                                             </tr>
                                         </table>
                                    <?php echo form_close();?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                        if(isset($_POST['search'])){
                           
                            $start = $_POST['date1'];
                            $end = $_POST['date2'];
                            $status = $_POST['status'];
                            $ticket = $_POST['ticket'];
                        
                    ?>

                    <div class="row gutters">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">User Search</div>

                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Request Date</th>
                                            <th>Ticket #</th>
                                            <th>Service Name</th>
                                            <th>Products Name</th>
                                            <th>Urgent</th>
                                            <th>Status</th>
                                            
                                            <th>Assigned User</th>
                                            <th>Alarm</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                            <?php
                                $uid = $this->session->userdata('user_id');
                                $sql = "SELECT * FROM `request` ";
                                if(!empty($_POST['ticket'])){
                                    $sql.="WHERE `ticket` = '$ticket'";
                                }
                                elseif(!empty($_POST['date1']) && empty($_POST['date2']) && empty($_POST['status']) ){
                                    $sql.="WHERE `req_date` = '$start'  AND `request_by` = '$uid' ORDER BY `req_id` DESC ";
                                }
                                elseif(!empty($_POST['date1']) && empty($_POST['date2']) && !empty($_POST['status']) ){
                                    $sql.="WHERE `req_date` = '$start'  AND  `status` = '$status' AND `request_by` = '$uid' ORDER BY `req_id` DESC ";
                                }
                                elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && empty($_POST['status']) ){
                                    $sql.="WHERE `req_date` BETWEEN '$start'  AND  '$end'  AND `request_by` = '$uid' ORDER BY `req_id` DESC ";
                                }

                                 elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && empty($_POST['status'])){
                                    $sql.="WHERE `req_date` BETWEEN '$start'  AND  '$end'  AND `request_by` = '$uid' ORDER BY `req_id` DESC ";
                                }
                                elseif(!empty($_POST['date1']) && !empty($_POST['date2']) && !empty($_POST['status'])){
                                    $sql.="WHERE `req_date` BETWEEN '$start'  AND  '$end' AND `status` = '$status' AND `request_by` = '$uid' ORDER BY `req_id` DESC ";
                                }elseif(empty($_POST['date1']) && empty($_POST['date2']) && !empty($_POST['status']) ){
                                    $sql.="WHERE `status` = '$status' AND `request_by` = '$uid' ORDER BY `req_id` DESC";
                                }
                                $query = $this->db->query($sql);
                                $result = $query->result();
                                if($query->num_rows()>0){
                                    foreach($result AS $row){
                            ?>

                                            <tr>
                                                    <td><?php echo date('d-M-Y h:i:s A',strtotime($row->req_date.$row->time))?></td>
                                                    <td><?php echo $row->ticket?></td>
                                                    <td><?php 
                                                        $service = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$row->service_name' "); 
                                                        if($service->num_rows() >0){
                                                            echo $service->row(0)->service_name;
                                                        }
                                                    ?></td>
                                                    <td><?php
                                                            $pro = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$row->products_name' "); 
                                                        if($pro->num_rows() >0){
                                                            echo $pro->row(0)->pro_name;
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                            if($row->urgent == 1){
                                                                echo "Yes";
                                                            }else{
                                                                echo "No";
                                                            }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                            $status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
                                                            if($status->num_rows()>0){
                                                                echo $status->row(0)->status_name;
                                                            }
                                                        ?>
                                                    </td>                                                   
                                                    <td><?php

                                                        $Asuser = $this->db->query("SELECT * FROM `executions` WHERE `req_id` ='$row->req_id' ");
                                                        if($Asuser->num_rows()>0){
                                                            $user = $Asuser->row(0)->exe_user;
                                                            $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$user' ");
                                                            if($uQuery->num_rows()==1){
                                                                echo $uQuery->row(0)->user_name;
                                                            }
                                                        }

                                                    ?></td>
                                                    <td class="text-center"><?php
                                                            $status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
                                                            if($status->num_rows()>0){
                                                                echo "<img class='img-circle circlediv' height='20' width='20' src='".base_url()."uploads/request/".$status->row(0)->image."'";
                                                            }
                                                        ?>
                                                            
                                                    </td>
                                                        <td><a class="btn btn-success btn-sm" href="<?php echo base_url()?>dashboard/view-request/<?php echo $row->req_id;?>">View Details</a></td>
                                                </tr>
                                        <?php } }else{?>

                                            <tr>
                                                <td colspan="9">No data Found</td>
                                                
                                            </tr>

                                        <?php }?>

                                    </tbody>
                                </table>


                            </div>
                        </div>
                    </div>














                    <?php }?>
                </div>
</div>