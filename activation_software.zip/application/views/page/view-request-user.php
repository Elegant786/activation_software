<div class="app-main">
                    <!-- BEGIN .main-heading -->
                   
				   <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Request</h5>
                                        <h6 class="sub-heading">View Request</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row gutters">
                        <?php
                        if($this->input->get('action')=='success' ){?>                            
                                
                                    <div class='modal hide fade top-margin' id='myModal'>
                                            <div class="card top-">
                                            <div class="card-header">Execution Status
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                                <div class="card-body bg-success">
                                                        Request Executed Successfully
                                                </div>
                                            </div>

                                    </div>
                       <?php } ?>
                        

                        <div class="col-md-12">
                            <div class="card">
                              <div class="card-header">Request Data</div>
                                <div class="card-body">
                                    <div class="col-md-6">
                                        <?php
                                            $id = $this->uri->segment(3);
                                            $query = $this->db->query("SELECT * FROM `request` WHERE `req_id` = '$id' ");
                                            $result = $query->result();
                                            foreach($result AS $request){
                                        ?>

                                        <table class="table table-resposive table-bordered">
                                            <tr>
                                                <td width="50%"><b>Traking#:</b>  <?php echo $request->ticket?> </td>
                                                <td><b>Activition Team:</b> <?php
                                                        $act = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` = '$request->activition_team' ");
                                                        if($act->num_rows() >0){
                                                            echo $act->row(0)->team_name;
                                                        }
                                                ?></td>
                                            </tr>
                                            <tr>
                                                <td width="50%"><b>Requested By:</b> <?php
                                                        $rq_by = $this->db->query("SELECT * FROM `users` WHERE `id` = '$request->request_by' ");
                                                        if($rq_by->num_rows() >0){
                                                            echo $rq_by->row(0)->user_name;
                                                        }?>
                                                    
                                                </td>
                                                <td><b>Requested Date:</b> <?php echo date("d-M-Y h:i:s A",strtotime($request->req_date.$request->time))?></td>
                                            </tr>
                                            <tr>
                                                <td width="50%"><b>Service Information:</b>
                                                    <?php
                                                        $service = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$request->service_name' ");
                                                        if($service->num_rows() >0){
                                                            echo $service->row(0)->service_name;
                                                        }
                                                    ?>

                                                </td>
                                                <td><b>Products Name:</b> 

                                                    <?php
                                                        $products = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$request->products_name' ");
                                                        if($products->num_rows() >0){
                                                            echo $products->row(0)->pro_name;
                                                        }
                                                    ?>

                                                </td>
                                            </tr>

                                            <tr>
                                                <td width="50%"><b>Quantity:</b> <?php echo $request->quantity?></td>
                                                <td><b>Remarks:</b> <p><?php echo $request->comments?></p></td>
                                            </tr>

                                             <tr>
                                                <td colspan="2"><b>Status:</b> <?php

                                                    $status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$request->status' ");
                                                    if($status->num_rows()>0){
                                                        echo $status->row(0)->status_name;
                                                    }

                                                ?></td>
                                                
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <b>Attach File:</b>
                                                    <?php if($request->file!=0){?>
                                                    <a href="<?php echo base_url()?>/download-file/<?php echo $request->file;?>" target="_blank"><?php echo $request->file;?></a>
                                                    <?php }else{?>
                                                        No File Included
                                                    <?php }?>
                                                </td>
                                            </tr>
                                        </table>
<!-- If user Is General User -->
<?php if($this->session->userdata('user_role')==3 || $this->session->userdata('user_role')==1){?>
                                        <div class="execution">
                                            <div class="title">Execution Details</div>
                                                <?php
                                                    $execution = $this->db->query("SELECT * FROM `executions` WHERE `req_id` = '$request->req_id' ");
                                                    $exe_result = $execution->result();
                                                    foreach($exe_result AS $exe){
                                                ?>
                                                    <table class="table table-responsive table-bordered">
                                                        <tr>
                                                            <td colspan="2">
                                                                <b>Executor:</b>
                                                                <?php 
                                                                $ex_user = $this->db->query("SELECT * FROM `users` WHERE `id` = '$exe->exe_user' ");
                                                                if($ex_user->num_rows()>0){
                                                                    echo $ex_user->row(0)->user_name;
                                                                }
                                                            ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <p><b>Remaning Quantity:</b> <?php echo $request->quantity-$exe->rem_qnt;?> </p>
                                                            </td>
                                                            <td>
                                                                <p><b>Execution Quantity:</b> <?php echo $exe->rem_qnt;?> </p>
                                                            </td>


                                                        </tr>
                                                        
                                                        <tr>
                                                            <td colspan="2">
                                                                <b>Execution User:</b> <p>
                                                                    <?php
                                                                        $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$exe->exe_user' ");
                                                                        if($uQuery->num_rows()==1){
                                                                            echo $uQuery->row(0)->user_name;
                                                                        }
                                                                    ?>
                                                                </p>
                                                            </td>
                                                        </tr>


                                                        <tr>
                                                            <td colspan="2">
                                                               <b> Executor Comments:</b> <p>
                                                                    <?php echo $exe->comments?>
                                                                </p>
                                                            </td>
                                                        </tr>

                                                    </table>



                                                <?php }?>
                                        </div>
                                        
                                     </div>
            <?php }elseif($this->session->userdata('user_role')==2){?>
 <!-- If USer Is A Admin -->
                        <div class="execution">
                            <div class="title">Execution Form</div>
                                
                                <?php
                                    $exquery = $this->db->query("SELECT * FROM `executions` WHERE `req_id` = '$request->req_id'  ");
                                    if($exquery->num_rows()==1){
                                        $exe_result = $exquery->result();
                                        foreach($exe_result AS $exe){
                                ?>
                                 <?php echo form_open_multipart("DashboardController/Execute")?>
                                <table class="table table-bordered">
                                         <tr>
                                            <td ><b>Select Attached File</b></td>
                                            <td colspan='23'><input type="file" name="image"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <b>Execution history</b>
                                                <br>
                                                <?php echo $exe->execution_date?>
                                            </td>
                                            
                                            <td>
                                                <b>Execution By</b>
                                                <br>
                                                <?php
                                                    $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$exe->exe_user' ");
                                                    if($uQuery->num_rows()==1){
                                                        echo $uQuery->row(0)->user_name;
                                                    }
                                                ?>
                                            </td colspan='3'>
                                        </tr>

                                        <tr>
                                            <td><b>Remainig Quantity:</b><?php $remaning = $request->quantity - $exe->rem_qnt; echo $remaning; ?></td>
                                            <td><b>Execution Quantity:</b>
                                                <input class="form-control col-md-5" type="text" name="exe_qnt" value="0">
                                            </td>
                                            <td>
                                                <b>Executed Quantity:</b> <?php echo $exe->rem_qnt;?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>Ticket Status</b></td>
                                            <td colspan="2">
                                                
                                                <select name="status" class="form-control col-md-6">
                                                    <?php
                                                        $status = $this->db->query("SELECT * FROM  `status` WHERE `sta_id` = '$request->status'");
                                                        $st_result = $status->result();
                                                        foreach($st_result AS $sta){
                                                    ?>
                                                    <option value="<?php echo $sta->sta_id?>"><?php echo $sta->status_name;?></option>
                                                    <?php }?>



                                                   <?php
                                                        $status = $this->db->query("SELECT * FROM  `status` WHERE `sta_id` != '$request->status'");
                                                        $st_result = $status->result();
                                                        foreach($st_result AS $sta){
                                                    ?>
                                                    <option value="<?php echo $sta->sta_id?>"><?php echo $sta->status_name;?></option>
                                                    <?php }?>
                                                </select>

                                            </td>
                                            
                                        </tr>
                                        <tr>
                                            <td colspan='3'><b>Executed User:</b>
                                                <?php
                                                    $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$exe->exe_user' ");
                                                    if($uQuery->num_rows()==1){
                                                        echo $uQuery->row(0)->user_name;
                                                    }
                                                ?>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td colspan="2"><b>comments:</b>
                                                <textarea class="form-control" name="comments"><?php echo $exe->comments?></textarea>
                                            </td>
                                        </tr>
                                    
                                    <?php
										
										//IF user Not Defined  OR Login User is a Assigned user 
										
                                        if($request->exe_user == $this->session->userdata('user_id') || empty($request->exe_user) ==TRUE){
                                    ?>    
                                    
                                        <tr>
                                            <td colspan="3">
                                                <input type="hidden" name="req_id" value="<?php echo $request->req_id?>">
                                                <button type="submit" name="submit" class="btn btn-success">Submit</button>
                                            </td>
                                        </tr>
                                    <?php }else{?>
                                            <tr>
                                                <td colspan="3">You have No Permission To execute</td>
                                            </tr>
                                    <?php }?>

                                </table>
                                     <?php } echo form_close()?>


                                <?php }else{?>
                                    <?php echo form_open_multipart("DashboardController/Execute")?>
                                    <table class="table table-bordered">
                                        <tr>
                                            <td><b>Select Attached File</b></td>
                                            <td><input type="file" name="image"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <b>Execution history</b>
                                                <br>
                                            </td>
                                            
                                            <td>
                                                <b>Execution By</b>
                                                <br>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td><b>Remainig Quantity:</b></td>
                                            <td><b>Execution Quantity:</b><input class="form-control col-md-2" type="text" name="exe_qnt" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td><b>Ticket Status</b></td>
                                            <td colspan="2">
                                                
                                                <select name="status" class="form-control col-md-6">
                                                    <option value="0">Select Status</option>
                                                    <?php
                                                        $status = $this->db->get('status');
                                                        $st_result = $status->result();
                                                        foreach($st_result AS $sta){
                                                    ?>
                                                    <option value="<?php echo $sta->sta_id?>"><?php echo $sta->status_name;?></option>
                                                    <?php }?>
                                                </select>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>Executed User:</b></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2"><b>comments:</b>
                                                <textarea class="form-control" name="comments"></textarea>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">
                                                <input type="hidden" name="req_id" value="<?php echo $request->req_id?>">
                                                <button type="submit" name="submit" class="btn btn-success">Submit</button>
                                            </td>
                                        </tr>
                                    </table>
                                    <?php echo form_close()?>

                                <?php }?>
                        </div>


            <?php }?>

    <?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($_GET['action'])=="success"){?>
<script>setTimeout(function(){window.location.href="<?php echo base_url()."dashboard/view-request/".$this->uri->segment(3)?>"},3000);</script>
<?php }?>