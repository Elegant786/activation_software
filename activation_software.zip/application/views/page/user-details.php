<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Services</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="modal" data-target="#myModal" data-placement="left" title="Download Reports">
                                            <i class="icon-edit"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <?php
                        if(isset($_POST['update'])){
                            $name = $this->input->post('name');
                            $user_id = $this->input->post('user_id');
                            $dname = $this->input->post('dname');
                            $email = $this->input->post('email');

                            $attr = array(
                                "user_name"             =>$name,
                                "email"                 =>$email,
                                "distribution_house"    =>$dname

                            );
                            $this->db->where('id',$user_id);
                            if($this->db->update('users',$attr)){
                                echo "<div class='alert bg-success font-white text-center'> User Updated</div>";
                            }else{
                                 echo "<div class='alert bg-danger font-white text-center'> User Not Updated </div>";
                            }
                        }
                    ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">User Data</div>
                                    <div class="card-body">
                                        <table class="table table-bordered">
                                            <tobdy>
                                                <?php
                                                    if(isset($user)){
                                                        foreach($user AS $row):
                                                ?>
                                                 <tr>
                                                   <td><b>User ID:</b>&nbsp <?php echo $row->user_id?></td>
                                                 </tr>

                                                <tr>
                                                   <td> <b>Name:</b> &nbsp <?php echo $row->user_name?></td>
                                                </tr>

                                                <tr>
                                                   <td><b>Email:</b>&nbsp <?php echo $row->email;?></td>
                                                </tr>

                                                <tr>
                                                   <td><b>Distrebution House:</b>&nbsp <?php echo $row->distribution_house?></td>
                                                </tr>
                                                <?php endforeach; }?>

                                            </tobdy>
                                        </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <?php echo form_open()?>
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Add User</h4>
                                </div>
                                <div class="modal-body">
                                        
                                    <?php
                                        if(isset($user)){
                                            foreach($user AS $row):
                                    ?>
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" value="<?php echo $row->user_name?>" required="required" name="name" class="form-control" placeholder="Enter Your Name">
                                           
                                        <input type="hidden" value="<?php echo $row->id?>" required="required" name="user_id" >
                                    </div>
                                        
                                    <div class="form-group">
                                        <label>Distribution House</label>
                                        <input type="text" value="<?php echo $row->distribution_house?>" required="required" name="dname" class="form-control" placeholder="Distribution House">
                                    </div>

                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" value="<?php echo $row->email?>" required="required" name="email" class="form-control" placeholder="Enter Your Email">
                                    </div>
                                    <?php endforeach; }?>
                                    
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" name="update" class="btn btn-primary">Update</button>
                                </div>
                                <?php echo form_close()?>
                            </div>
                        </div>
                    </div>
                </div>
</div>