<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-beaker"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Request</h5>
                                        <h6 class="sub-heading">New Request</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                   
                    <div class="row">
                    <?php
                        if($this->input->get('action')=='success' ){?>                            
                                
                                    <div class='modal hide fade top-margin' id='myModal'>
                                            <div class="card top-">
                                            <div class="card-header">New Request Form
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                                <div class="card-body bg-success">
                                                        Your Request is Successfully Submited To Admin :) Thank You
                                                </div>
                                            </div>

                                    </div>
                       <?php } ?>

                        <div class="col-md-5">
                            <div class="card">
                            <div class="card-header">New Request Form</div>
                                <div class="card-body">
                                    <?php echo form_open_multipart("DashboardController/MakeRequets")?>
                                            <div class="form-group">
                                                <label for="req_id">Ticket</label>
                                                
                                                <?php
                                                    $req = $this->db->get('request');
                                                    $req_res = $req->num_rows();
                                                    if($req_res>=0){
                                                ?>

                                                <input type="hidden" id="req_id" name="id" value="<?php echo date('Ymdhsi').$req_res;?>" class="form-control">
                                                <input type="text" disabled="disabled" id="req_id" name="id" value="<?php echo date('Ymdhsi').$req_res;?>" class="form-control">
                                                <?php }?>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="title">Request Title</label>
                                                <input type="text" name="title" id="title" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label for="team">Activition Team</label>
                                                    <select onchange="GetService(this.value)" name="team" id="team" class="form-control select2">
                                                        <option value="0">Select Team</option>
                                                        <?php 
                                                            $query = $this->db->get('activition_team');
                                                            $result = $query->result();
                                                            foreach($result AS $row){
                                                        ?>
                                                        <option value="<?php echo $row->team_id?>"><?php echo $row->team_name?></option>
                                                        <?php }?>
                                                    </select>
                                            </div>
                                            <div id="services" class="form-group">
                                                <label for="services">Services</label>
                                                <select onchange="GetProducts(this.value)" name="service" id="service" class="form-control">
                                                    
                                                </select>
                                            </div>
                                            <div class="form-group">
                                               <label for="products">Products</label>
                                                <select name="products" id="products" class="form-control">
                                                    
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="qnt">Total Quantity</label>
                                                <input type="text" name="qnt" id="qnt" class="form-control">
                                            </div>

                                            <div class="form-group">
                                                <label for="arg"><input type="checkbox" name="argent" value="1" id="arg"> Urgent</label>                                                
                                            </div>

                                            <div class="form-group">
                                                <label for="remarks">Remarks</label>
                                                <textarea name="remarks" id="remarks" cols="30" rows="6" class="form-control"></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label for="image">Attach File</label>
                                                <input type="file" name="image" id="image" class="form-control">
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="mail"><input data-toggle="modal" data-target="#myModal" type="checkbox" name="mail" value="1" id="mail"> Show Mail Editor</label>
                                            </div>

                                            <div class="form-group">
                                                <button type="submit" name="submit" class="btn btn-success">Submit</button>
                                            </div>
                                    <?php echo form_close()?>

                                    

                                </div>
                            </div>
                        </div>

                        <div class="col-md-5 " id="mailStatus">
                                
                        </div>

                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Send Mail</h4>
                                </div>
                                <div class="modal-body">
                                    
                                    <div class="form-group">
                                        <label>Mail To</label>
                                        <input type="email" name="email" class="form-control" id="email">
                                    </div>
                                    <div class="form-group">
                                        <label>BCC</label>
                                        <input type="email" name="bcc" class="form-control" id="bcc">
                                    </div>
                                    <div class="form-group">
                                        <label>CC</label>
                                        <input type="email" name="cc" class="form-control" id="cc">
                                    </div>
                                    <div class="form-group">
                                        <label>Subject</label>
                                        <input type="text" name="cc" class="form-control" id="subject">
                                    </div>
                                    <div class="form-group">
                                        <label for="remarks">Massege</label>
                                        <textarea name="massage" id="massage" cols="30" rows="6" class="form-control"></textarea>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="attach"><input type="checkbox" name="attach" value="1" id="attach"> Send Attachment</label>
                                    </div>
                                    <button class="btn btn-success" type="submit" onclick="SendMail(email.value,bcc.value,cc.value,massage.value)">Send Mail</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
</div>

<script type="text/javascript">
    function GetService(str) {
       
            if (str.length == 0) { 
                document.getElementById("service").style.display="none";
                return;
            } else {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("service").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "<?php echo base_url()?>DashboardController/GerSrevices/"+str, true);
                xmlhttp.send();
            }
        }

    function GetProducts(str){
        
        if (str.length == 0) { 
                document.getElementById("products").style.display="none";
                return;
            } else {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        var responseReq = this.responseText;
                        if(responseReq == "TRUE"){

                        }else{
                            document.getElementById("products").innerHTML = this.responseText;                            
                        }
                    }
                };
                xmlhttp.open("GET", "<?php echo base_url()?>DashboardController/GetProducts/"+str, true);
                xmlhttp.send();
            }
        }

    function SendMail(to,bcc,cc,message){
        var attach = document.getElementById("image").value;        
        if (to.length == 0) { 
                document.getElementById("products").style.display="none";
                return;
            } else {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("products").innerHTML = this.responseText;
                    }
                };
        if(document.getElementById("attach").checked===true){
            xmlhttp.open("GET", "<?php echo base_url()?>DashboardController/sendEmail/?to="+to+"&bcc="+bcc+"&cc="+cc+"&message="+message+"&attach="+attach, true);
        }else{
             xmlhttp.open("GET", "<?php echo base_url()?>DashboardController/sendEmail/?to="+to+"&bcc="+bcc+"&cc="+cc+"&message="+message, true);
        }
          xmlhttp.send();
        }
    }


</script>
<?php if(isset($_GET['action'])=="success"){?>
<script>setTimeout(function(){window.location.href='<?php echo base_url()?>dashboard/new-request'},3000);</script>
<?php }?>