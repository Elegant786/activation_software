<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Services</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    
                <!--- Services Insert Start -->
                    <?php
                        if(isset($_POST['submit'])){
                    ?>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <?php
                                    $service_name = $this->input->post('ser_name');
                                    $service = ucfirst($service_name);
                                    $team = $this->input->post('team');
                                    if($this->db->insert('services',array('service_name' => $service,'team_id' => $team)) == TRUE){
                                        echo "<div class='alert bg-success'>Service Added</div>";
                                    }else{
                                        echo "<div class='alert bg-danger'>Service Not Added</div>";

                                    }

                                ?>
                            </div>
                        </div>
                    <?php }?>
                    <!--- Services Insert End -->
                    <!--- Services Update  Start-->
                    <?php
                        if(isset($_POST['update'])){
                            $service_name = $this->input->post('ser_name');
                            $service = ucfirst($service_name);
                            $id = $this->input->post('id');
                            $team = $this->input->post('team');
                            $this->db->where('ser_id',$id);
                            if($this->db->update('services',array('service_name' =>$service,'team_id' => $team )) == TRUE){
                                redirect('dashboard/settings/serviecs?action=success','refresh');
                            }else{
                                echo  "
                                         <div class='row'>
                                             <div class='col-md-12 text-center'>
                                               <div class='alert bg-danger'> Service no Update</div>
                                             </div>
                                         </div>
                                ";
                            }
                        }

                    ?>
                    <!--- Services Update End -->
                     <div class="row">
                       
                    <?php
                        if($this->uri->segment(4) && $this->uri->segment(3)=='edit'){

                    ?>
                        <?php
                            $ser = $this->uri->segment(4);
                            $query = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$ser' ");
                            $result = $query->result();
                            foreach($result AS $row){
                        ?>
<!-- Uodate form Start -->

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Edit Service</div>
                                <div class="card-body">
                                    <?php echo form_open()?>
                                        <div class="form-group">
                                            <label for="service_name"> Service Name </label>
                                            <input required="required" type="text" value="<?php echo $row->service_name?>" class="form-control" type="text" name="ser_name">
                                            <input type="hidden" name="id" value="<?php echo $row->ser_id?>">
                                        </div>


                                         <div class="form-group">
                                            <label>Select Team</label>
                                            <select name="team" class="form-control select2">
                                                <?php
                                                   $queryNew = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` = '$row->team_id'");
                                                   $result2 = $queryNew->result();
                                                    foreach($result2 AS $row2){
                                                ?>
                                                  <option value="<?php echo $row2->team_id?>"><?php echo $row2->team_name?></option>
                                                  <?php }?>
                                                <?php 
                                                    $query = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` != '$row->team_id'");
                                                    $result = $query->result();
                                                    foreach($result AS $row){
                                                ?>    
                                                    <option value="<?php echo $row->team_id?>"><?php echo $row->team_name?></option>
                                                <?php }?>

                                            </select>
                                        
                                        </div>

                                        <div class="form-group">
                                            <button class="btn btn-success" name="update" type="submit">Update</button>
                                        </div>
                                    <?php echo form_close()?>
                                </div>
                            </div>
                        </div>
<!-- Uodate form End -->

                    <?php  }?>

                      <?php  }else{  ?>

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Add new Service</div>
                                <div class="card-body">
                                    <?php echo form_open()?>
                                        <div class="form-group">
                                            <label for="service_name"> Service Name </label>
                                            <input required="required" id="service_name" type="text" class="form-control" type="text" name="ser_name">
                                        </div>

                                        <div class="form-group">
                                            <label>Select Team</label>
                                            <select name="team" class="form-control select2">
                                                    <option>Select One</option>
                                                  
                                                <?php 
                                                    $query = $this->db->get('activition_team');
                                                    $result = $query->result();
                                                    foreach($result AS $row){
                                                ?>    
                                                    <option value="<?php echo $row->team_id?>"><?php echo $row->team_name?></option>
                                                <?php }?>

                                            </select>
                                        
                                        </div>

                                        <div class="form-group">
                                            <button class="btn btn-success" name="submit" type="submit">Create</button>
                                        </div>
                                    <?php echo form_close()?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">All Services</div>
                                <div class="card-body">
                                        <table class="table table-bordered table-responsive">
                                            <thead>
                                                <tr>
                                                    <td width="20">S/N</td>
                                                    <td>Serviec Name</td>
                                                    <td width="80">Action</td>                                                    
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php 
                                                    $query = $this->db->get("services");
                                                    $result = $query->result();
                                                    foreach($result AS $row){
                                                        @$sl++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $sl;?></td>
                                                    <td><?php echo $row->service_name;?></td>
                                                    <td>                                                            
                                                        <div class="dropdown">
                                                          <a class="btn btn-warning dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            Action
                                                          </a>
                                                          <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                            <a class="dropdown-item" href="<?php echo base_url()?>dashboard/serviecs/edit/<?php echo $row->ser_id?>">Edit</a>
                                                            <a onclick="return confirm('Are you sure want to delete <?php echo $row->service_name?> ?')" class="dropdown-item" href="<?php echo base_url()?>dashboard/serviecs/delete/<?php echo $row->ser_id?>">Delete</a>
                                                          </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php }?>
                                            </tbody>
                                        </table>
                                </div>
                            </div>
                        </div>
                    <?php }?>

                    </div>


                </div>
</div>