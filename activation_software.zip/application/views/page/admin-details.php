<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Services</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="modal" data-target="#myModal" data-placement="left" title="Download Reports">
                                            <i class="icon-edit"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <?php
                        if(isset($_POST['update'])){
                            $name = $this->input->post('name');
                            $user_id = $this->input->post('user_id');
                            $ac_team = $this->input->post('ac_team');
                            $email = $this->input->post('email');

                            $attr = array(
                                "user_name"     =>$name,
                                "email"         =>$email,
                                "active_team "  =>$ac_team

                            );
                            $this->db->where('id',$user_id);
                            if($this->db->update('users',$attr)){
                                echo "<div class='alert bg-success font-white text-center'> User Updated</div>";
                            }else{
                                 echo "<div class='alert bg-danger font-white text-center'> User Not Updated </div>";
                            }
                        }
                    ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Admin Data</div>
                                    <div class="card-body">
                                        <table class="table table-bordered">
                                            <tobdy>
                                                <?php
                                                    if(isset($user)){
                                                        foreach($user AS $row):
                                                ?>
                                                 <tr>
                                                   <td><b>User ID:</b>&nbsp <?php echo $row->user_id?></td>
                                                 </tr>

                                                <tr>
                                                   <td> <b>Name:</b> &nbsp <?php echo $row->user_name?></td>
                                                </tr>

                                                <tr>
                                                   <td><b>Email:</b>&nbsp <?php echo $row->email;?></td>
                                                </tr>

                                                <tr>
                                                   <td><b>Activition Team:</b>&nbsp <?php  $query = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` = '$row->active_team' ");
                                                        if($query->num_rows()>0){
                                                            echo $query->row(0)->team_name;
                                                        }?></td>
                                                </tr>

                                                <tr>
                                                    <td><b>Role:</b> <?php if($row->user_role == 1 ){ echo "Super Admin"; }elseif($row->user_role == 2){ echo "Admin"; }?></td>
                                                </tr>
                                                <tr>
                                                    <td><b>Create Date:</b> <?php echo date('d-m-Y',strtotime($row->created_date));?></td>
                                                </tr>
                                                <?php endforeach; }?>

                                            </tobdy>
                                        </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <?php echo form_open()?>
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Add User</h4>
                                </div>
                                <div class="modal-body">
                                        
                                    <?php
                                        if(isset($user)){
                                            foreach($user AS $row):
                                    ?>
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" value="<?php echo $row->user_name?>" required="required" name="name" class="form-control" placeholder="Enter Your Name">
                                           
                                        <input type="hidden" value="<?php echo $row->id?>" required="required" name="user_id" >
                                    </div>
                            
                            <?php
                                // if user is Admin 
                                if($row->user_role == 2 ){
                            ?>


                                    <div class="form-group">
                                        <label>Activition Team</label><br>
                                        <select  class="form-control" name="ac_team">
                                            <?php 
                                                $query3 = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` = '$row->active_team' ");
                                                $result3 = $query3->result();
                                                foreach($result3 AS $row3){
                                            ?>

                                            <option value="<?php echo $row3->team_id?>"><?php echo $row3->team_name?></option>
                                            <?php }?>


                                            <?php 
                                                $query2 = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` != '$row->active_team' ");
                                                $result2 = $query2->result();
                                                foreach($result2 AS $row2){
                                            ?>

                                            <option value="<?php echo $row2->team_id?>"><?php echo $row2->team_name?></option>
                                            <?php }?>
                                        </select>
                                    </div>


                        <?php }?>

                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" value="<?php echo $row->email?>" required="required" name="email" class="form-control" placeholder="Enter Your Email">
                                    </div>
                                    <?php endforeach; }?>
                                    
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" name="update" class="btn btn-primary">Update</button>
                                </div>
                                <?php echo form_close()?>
                            </div>
                        </div>
                    </div>
                </div>
</div>