<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Change Password</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row">
                        <div class="col-md-12">
                            <?php 
                                if(isset($_POST['change'])){
                                    $opass = md5("Elegant@2017".$this->input->post('opass'));
                                    $pass = $this->input->post('password');
                                    $cpass = $this->input->post('cpass');

                                    if($opass == $this->session->userdata('password')){
                                        if(md5($pass) == md5($cpass)){

                                            $password = md5("Elegant@2017".$pass);
                                            $this->db->where('id',$this->session->userdata('user_id'));
                                            
                                            if($this->db->update('users',array('password'=>$password))){
                                            
                                                    unset($_SESSION['password']);
                                                    $_SESSION['password'] = $password;
                                                    echo "<div class='alert bg-success'> Password Changed </div>";
                                            }else{
                                                    echo "<div class='alert bg-danger'> Password not Change </div>";

                                            }

                                        }else{
                                            echo "<div class='alert bg-danger'>".md5($pass)."  ".md5($cpass)."</div>";
                                        }
                                    }else{
                                            echo "<div class='alert bg-danger'>Old Password is not valid</div>";

                                    }
                                }
                            ?>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Change Password</div>
                                <div class="card-body">
                                    <?php echo form_open()?>
                                            <div class="form-group">
                                                <label for="old_pass"> Old Password</label>
                                                <input required="required" type="password" id="old_pass" name="opass" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label for="password">New Password</label>
                                                <input required="required" type="password" id="password" name="password" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label for="cpass">Confirm Password</label>
                                                <input required="required" id="cpass" type="password" name="cpass" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-success" name="change" type="submit">Change Password</button>
                                            </div>
                                    <?php echo form_close()?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>