<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Services</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                    <div class="row">
                        <div class="col-md-12">
                            <?php
                                /****** Products Insert *******/
                                if(isset($_POST['add_pro'])){
                                    $pro_name = $this->input->post('products');
                                    $service = $this->input->post('service');
                                    $attr = array(
                                        'pro_name'  =>$pro_name,
                                        'ser_id '   => $service

                                    ); 
                                    if($this->db->insert('products',$attr)){
                                        echo "<div class='alert bg-success'> Products Added </div>";
                                    }else{
                                        echo "<div class='alert bg-danger'> Products not add </div>";
                                    }
                                }
                                 /****** Products Update *******/

                                 if(isset($_POST['update'])){
                                        $pro_name = $this->input->post('products');
                                        $service = $this->input->post('service');
                                        $attr = array(
                                            'pro_name'  =>$pro_name,
                                            'ser_id '   => $service

                                        ); 
                                        $this->db->where('pro_id',$this->input->post('id'));
                                        if($this->db->update('products',$attr)){
                                          redirect('dashboard/settings/products','refresh');
                                        }else{
                                            echo "<div class='alert bg-success'> Products Not Updated </div>";
                                        }
                                 }
                            ?>
                        </div>
                    </div>

                    <div class="row">
                        

                        <?php
                            if($this->uri->segment(4)){
                        ?>                        
            <!-- Products Update Form-->
                      
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Products</div>
                                <div class="card-body"> 
                                    <?php echo form_open()?>
                                        <?php
                                            $id = $this->uri->segment(5);
                                            $query = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$id' ");
                                            $result = $query->result();
                                            foreach($result AS $row){
                                        ?>

                                        <div class="form-group">
                                            <label>Products name</label>
                                            <input type="text" value="<?php echo $row->pro_name?>" name="products" class="form-control">
                                            <input type="hidden" name="id" value="<?php echo $row->pro_id?>">
                                        </div>

                                        <div class="form-group">
                                            <label>Service</label>
                                            <select name="service" class="form-control select2">
                                                
                                                <?php
                                                     $query2 = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$row->ser_id'");
                                                    $result2 = $query2->result();
                                                    foreach($result2 AS $row2){
                                                ?>

                                                <option value="<?php echo $row2->ser_id?>"><?php echo $row2->service_name?></option>
                                                <?php }?>

                                                <?php 
                                                    $query = $this->db->query("SELECT * FROM `services` WHERE `ser_id` != '$row->ser_id'");
                                                    $result = $query->result();
                                                    foreach($result AS $row){                                                       
                                                ?>
                                                <option value="<?php echo $row->ser_id?>"> <?php echo $row->service_name?> </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                    <?php }?>
                                        <div class="form-group">
                                            <button class="btn btn-success" type="submit" name="update">Add Product</button>
                                        </div>
                                            
                                    <?php echo form_close()?>
                                </div>
                            </div>
                        </div>

           <!-- Products Update Form End-->
                        <?php }else{?>
                        
                        <!-- Products Add Form-->
                        
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Create Products</div>
                                <div class="card-body"> 
                                    <?php echo form_open()?>
                                        <div class="form-group">
                                            <label>Products name</label>
                                            <input type="text" name="products" class="form-control">
                                        </div>

                                        <div class="form-group">
                                            <label>Service</label>
                                            <select name="service" class="form-control select2">
                                                
                                                <option> Select one</option>
                                                <?php 
                                                    $query = $this->db->get("services");
                                                    $result = $query->result();
                                                    foreach($result AS $row){                                                       
                                                ?>
                                                <option value="<?php echo $row->ser_id?>"> <?php echo $row->service_name?> </option>
                                                <?php }?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <button class="btn btn-success" type="submit" name="add_pro">Add Product</button>
                                        </div>
                                            
                                    <?php echo form_close()?>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="card">
                              <div class="card-header">Products</div>
                                <div class="card-body">
                                    <table class="table table-border table-responsive">
                                        <thead>
                                            <tr>
                                                <td width="20">S/N</td>
                                                <td>Products name</td>
                                                <td>Service Name</td>
                                                <td>Action</td>
                                                
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php 
                                                $query = $this->db->select("*")
                                                                 ->from("products")
                                                                 ->join('services',"`products`.`ser_id` = `services`.`ser_id` ")
                                                                 ->get();
                                                $result = $query->result();
                                                foreach($result AS $row){
                                                    @$sl++;
                                            ?>
                                            <tr>
                                                <td><?php echo $sl;?></td>
                                                <td><?php echo $row->pro_name?></td>
                                                <td><?php  echo $row->service_name?></td>
                                                <td>
                                                    
                                                    <div class="dropdown">
                                                          <a class="btn btn-warning btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            Action
                                                          </a>
                                                          <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                            <a class="dropdown-item" href="<?php echo base_url()?>dashboard/settings/products/edit/<?php echo $row->pro_id?>">Edit</a>
                                                            <a onclick="return confirm('Are you sure want to delete <?php echo $row->pro_name?> ?')" class="dropdown-item" href="<?php echo base_url()?>products/delete/<?php echo $row->pro_id?>">Delete</a>
                                                          </div>
                                                    </div>


                                                </td>
                                            </tr>
                                            <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

             <!-- Products Add Form End-->

                        <?php }?>
                    </div>
                </div>
</div>