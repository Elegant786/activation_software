<script type="text/javascript">
  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {

    var data = google.visualization.arrayToDataTable([
      ['Task', 'Hours per Day'],
    
    <?php
		$status = $this->db->query("SELECT * FROM  `status`");
		$str= $status->result();
		foreach($str AS $rqStat){ 
			$request = $this->db->query("SELECT * FROM `request` WHERE  `status` = '$rqStat->sta_id'  ");
	?>

      ['<?php echo $rqStat->status_name;?>',     <?php echo $request->num_rows()?>],
     <?php }?>

    ]);

    var options = {
      title: 'Total Activits'
    };

    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

    chart.draw(data, options);
  }
</script>

<div class="app-main">
					<!-- BEGIN .main-heading -->
					<header class="main-heading">
						<div class="container-fluid">
							<div class="row">
								<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
									<div class="page-icon">
										<i class="icon-laptop_windows"></i>
									</div>
									<div class="page-title">
										<h5>Dashboard</h5>
										<h6 class="sub-heading">Welcome to Unify Admin Template</h6>
									</div>
								</div>
								<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
									<div class="right-actions">
										<a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
											<i class="icon-download4"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					</header>
					<!-- END: .main-heading -->
					<!-- BEGIN .main-content -->
				<div class="main-content">

						<div class="row gutters">
							
						<?php
							$status = $this->db->query("SELECT * FROM  `status`");
							$str= $status->result();
							foreach($str AS $rqStat){ 
								$request = $this->db->query("SELECT * FROM `request` WHERE  `status` = '$rqStat->sta_id'  ");

						?>
							
								<div class="col-lg-2">
									<div class="card">
										<div class="card-body">
											<a href="<?php echo base_url()?>dashbboard/view-super/by-status/<?php echo $rqStat->sta_id?>">
												<div class="stats-widget">
													<div class="stats-widget-header">
														<img class="circlediv" src="<?php echo base_url()?>uploads/request/<?php echo $rqStat->image ?>">
													</div>
													<div class="stats-widget-body">
														<!-- Row start -->
														<ul class="row no-gutters">
															<li class="col-lg-9">
																<h5 class="title"><?php echo $rqStat->status_name;?></h5>
															</li>
															<li class="col-lg-3">
																<h4 class="total"><?php echo $request->num_rows()?></h4>
															</li>
														</ul>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
							
						<?php }?>

						</div>

						<div class="row">
							
									<div class="col-md-6">
										<div class="card">
										<div class="card-body">		
										<?php echo form_open()?>									
												<table class="table table-bordered">
														<tr>
															<td>Execution Date:</td>
															<td colspan="2"><input name="date" class="form-control" type="date"></td>
														</tr>

												<tr>
													<td>Activition Team:</td>
													<td colspan="2">
														<select onclick="getExName(this.value)" name="active" class="form-control">
															<option value="0"> Please Select....</option>
															<?php
																
																$query = $this->db->query("SELECT * FROM `activition_team`");
																$result = $query->result();
																foreach($result AS $row){
															?>
															<option value="<?php echo $row->team_id?>"><?php echo $row->team_name?></option>
															<?php }?>
														</select>
													</td>
												</tr>

														<tr>
															<td>Executor Name:</td>
															<td>
																<select name="name" id="users" class="form-control">
																
																</select>													
															</td>
															<td>
																<button name="search" class="btn btn-success" type="submit">Search</button>
															</td>
														</tr>
												</table>

											<?php echo form_close()?>				
											</div>											
										
										</div>
									</div>
									<div class="col-md-6">
										<div class="card">
												<div class="card-body">
													<div id="piechart"></div>
											</div>
										</div>
									</div>
						</div>

						<?php
							if(isset($_POST['search'])){
						?>
									<div class="row">										
										<div class="col-md-12">
											<div class="card">
												<div class="card-body">
													<table class="table table-bordered">
															<thead>
																<tr>
																	<th>Request Date</th>
																	<th>Ticket #</th>
																	<th>Service Name</th>
																	<th>Products Name</th>
																	<th>Urgent</th>
																	<th>Status</th>	
																	<th>Assigned User</th>
																	<th>Alarm</th>
																	<th>Action</th>
																</tr>
															</thead>

															<tbody>
																<?php
																	$date = $this->input->post('date');
																	if(isset($_POST['name']) && $_POST['name'] !=0 ){
																		$name = $_POST['name'];
																	}elseif(isset($_POST['name']) && $_POST['name'] =NULL){
																		$name = NULL;
																	}else{
																		$name = NULL;
																	}

																	if(isset($_POST['active']) && $_POST['active'] !=0 ){
																		$active = $_POST['active'];
																	}else{
																		$active = NULL;
																	}

																	$sql = "SELECT * FROM `request` ";

																	/**************************** 
																		 Search statment Start 
																	*****************************/
																if(!empty($_POST['date']) && $name == NULL && $active==NULL){
																	$sql.="WHERE `req_date` = '$date' ";
																}

																elseif(!empty($_POST['date']) && $name == NULL && $active != NULL){
																	$sql.="WHERE `activition_team` = '$active'  AND `req_date` = '$date'";
																}

																elseif(empty($_POST['date']) && $name != NULL && $active != NULL){
																	$sql.="WHERE `activition_team` = '$active' AND `exe_user` = '$name' ";
																}

																elseif(empty($_POST['date']) && $name == NULL && $active != NULL){
																	$sql.="WHERE `activition_team` = '$active'";
																}

																elseif(!empty($_POST['date']) && $name == NULL && $active != NULL){
																	$sql.="WHERE `activition_team` = '$active' AND `req_date` = '$date' ";
																}



																	$query = $this->db->query($sql);
																	$result = $query->result();

																	/******* Fetching Data*******/
																	foreach($result AS $row){
																?>

																<tr>
													<td><?php echo date('d-M-Y h:i:s A',strtotime($row->req_date.$row->time))?></td>
													<td><?php echo $row->ticket?></td>
													<td><?php 
														$service = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$row->service_name' "); 
														if($service->num_rows() >0){
															echo $service->row(0)->service_name;
														}
													?></td>
													<td><?php
															$pro = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$row->products_name' "); 
														if($pro->num_rows() >0){
															echo $pro->row(0)->pro_name;
														}
														?>
													</td>
													<td>
														<?php
															if($row->urgent == 1){
																echo "Yes";
															}else{
																echo "No";
															}
														?>
													</td>
													<td>
														<?php
															$status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
															if($status->num_rows()>0){
																echo $status->row(0)->status_name;
															}
														?>
													</td>													
													<td>
														<?php 
														$Asuser = $this->db->query("SELECT * FROM `executions` WHERE `req_id` ='$row->req_id' ");
                                                        if($Asuser->num_rows()>0){
                                                            $user = $Asuser->row(0)->exe_user;
                                                            $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$user' ");
                                                            if($uQuery->num_rows()==1){
                                                                echo $uQuery->row(0)->user_name;
                                                            }
                                                        }

													?>
													</td>
													<td class="text-center"><?php
															$status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
															if($status->num_rows()>0){
																echo "<img class='img-circle circlediv' height='20' width='20' src='".base_url()."uploads/request/".$status->row(0)->image."'";
															}
														?></td>
														<td><a class="btn btn-success btn-sm" href="<?php echo base_url()?>dashboard/view-request/<?php echo $row->req_id;?>">View Details</a></td>
														</tr>
																<?php }?>

															</tbody>
													</table>

												</div>
											</div>
										</div>
									</div>

						<?php }else{?>
								<div class="row">										
										<div class="col-md-12">
											<div class="card">
												<div class="card-body">
													<table class="table table-bordered">
															<thead>
																<tr>
																	<th>Request Date</th>
																	<th>Ticket #</th>
																	<th>Service Name</th>
																	<th>Products Name</th>
																	<th>Urgent</th>
																	<th>Status</th>	
																	<th>Assigned User</th>
																	<th>Alarm</th>
																	<th>Action</th>
																</tr>
															</thead>

															<tbody>
																<?php
																	
																	$query = $this->db->query("SELECT * FROM `request`  ORDER BY `req_id`  DESC LIMIT 15");
																	$result  = $query->result();
																	foreach($result AS $row){
																?>
																<tr>
													<td><?php echo date('d-M-Y h:i:s A',strtotime($row->req_date.$row->time))?></td>
													<td><?php echo $row->ticket?></td>
													<td><?php 
														$service = $this->db->query("SELECT * FROM `services` WHERE `ser_id` = '$row->service_name' "); 
														if($service->num_rows() >0){
															echo $service->row(0)->service_name;
														}
													?></td>
													<td><?php
															$pro = $this->db->query("SELECT * FROM `products` WHERE `pro_id` = '$row->products_name' "); 
														if($pro->num_rows() >0){
															echo $pro->row(0)->pro_name;
														}
														?>
													</td>
													<td>
														<?php
															if($row->urgent == 1){
																echo "Yes";
															}else{
																echo "No";
															}
														?>
													</td>
													<td>
														<?php
															$status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
															if($status->num_rows()>0){
																echo $status->row(0)->status_name;
															}
														?>
													</td>													
													<td>
														<?php 
														$Asuser = $this->db->query("SELECT * FROM `executions` WHERE `req_id` ='$row->req_id' ");
                                                        if($Asuser->num_rows()>0){
                                                            $user = $Asuser->row(0)->exe_user;
                                                            $uQuery = $this->db->query("SELECT * FROM `users` WHERE `id` = '$user' ");
                                                            if($uQuery->num_rows()==1){
                                                                echo $uQuery->row(0)->user_name;
                                                            }
                                                        }

													?>
													</td>
													<td class="text-center"><?php
															$status = $this->db->query("SELECT * FROM `status` WHERE `sta_id` = '$row->status' ");
															if($status->num_rows()>0){
																echo "<img class='img-circle circlediv' height='20' width='20' src='".base_url()."uploads/request/".$status->row(0)->image."'>";
															}
														?></td>
														<td><a class="btn btn-success btn-sm" href="<?php echo base_url()?>dashboard/view-request/<?php echo $row->req_id;?>">View Details</a></td>
												</tr>

																<?php }?>
															</tbody>
													</table>

												</div>
											</div>
										</div>
									</div>



						<?php }?>
					<!-- END: .main-content -->
				</div>

<script type="text/javascript">
	function getExName(str) {
       
            if (str.length == 0) { 
                document.getElementById("users").style.display="none";
                return;
            } else {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("users").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "<?php echo base_url()?>DashboardController/GetActivitionMembers/"+str, true);
                xmlhttp.send();
            }
        }
</script>