<div class="col-md-12" >
                            <div class="card">
                                <div class="card-header">All Users</div>
                                <div class="card-body">
                                        <table class="table table-bordered table-responsive">
                                            <thead>
                                                <tr>
                                                    <td width="40">UserId</td>
                                                    <td>User Name</td>                                                    
                                                    <td>Email</td>
                                                    <td>Activition Team</td>
                                                    <td>Role</td>
                                                    <td>Action</td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    if(isset($users)){
                                                        foreach($users AS $row){
                                                ?>
                                                <tr>
                                                    <td><?php echo $row->user_id?></td>
                                                    <td><?php echo $row->user_name?></td>
                                                    
                                                    <td><?php echo date('d-m-Y',strtotime($row->created_date))?></td>
                                                    <td>
                                                    <?php
                                                        $query = $this->db->query("SELECT * FROM `activition_team` WHERE `team_id` = '$row->active_team' ");
                                                        if($query->num_rows()>0){
                                                            echo $query->row(0)->team_name;
                                                        }
                                                    ?>

                                                    </td>
                                                    <td>Admin</td>
                                                    <td>
                                                        
                                                        <div class="dropdown">
                                                              <a class="btn btn-warning dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                Action
                                                              </a>
                                                              <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                                 <a class="dropdown-item" href="<?php echo base_url()?>user/admin-change-password/<?php echo $row->id?>">Change password</a>

                                                                <a class="dropdown-item" href="<?php echo base_url()?>admin/details/<?php echo $row->id?>">Edit</a>
                                                                            
                                                                <a onclick="return confirm('Are you sure want to delete <?php echo $row->user_name?> ?')" class="dropdown-item" href="<?php echo base_url()?>admin/delete/<?php echo $row->id?>">Delete</a>
                                                              </div>
                                                        </div>



                                                    </td>
                                                </tr>
                                                <?php } ?>
                                                <tr>
                                                    <td colspan="6"><?php echo $this->pagination->create_links()?></td>
                                                </tr>
                                                <?php }?>
                                            </tbody>
                                        </table>
                                </div>
                            </div>
                        </div>