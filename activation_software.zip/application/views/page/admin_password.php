<div class="app-main">
                    <!-- BEGIN .main-heading -->
                    <header class="main-heading">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                                    <div class="page-icon">
                                        <i class="icon-cogs"></i>
                                    </div>
                                    <div class="page-title">
                                        <h5>Settings</h5>
                                        <h6 class="sub-heading">Services</h6>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                                    <div class="right-actions">
                                        <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                            <i class="icon-download4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                
                <div class="main-content">
                                     <div class="row gutters">
                                            <?php
                                                if(isset($_POST['submit'])){
                                                    $pass = $this->input->post('pass');
                                                    $cpass = $this->input->post('cpass');
                                                    if($pass != $cpass){
                                                        echo "<div class='col-md-12'><div class='alert bg-danger'> Password And Confirm  Password Not Match </div></div>";
                                                    }else{
                                                        $password = md5("Elegant@2017".$pass);
                                                        $this->db->where('id',$this->input->post('id'));
                                                        if($this->db->update('users',array('password' => $password))==TRUE){
                                                            echo "<div class='col-md-12'><div class='alert bg-success'>Password Changed</div></div>";
                                                        }else{
                                                            echo "<div class='col-md-12'><div class='alert bg-warning'>Password  Not Changed</div></div>";
                                                        }
                                                    }
                                                }
                                            ?>
                                     </div>

                    <div class="row gutters">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Change Password</div>
                                <div class="card-body">
                                    <?php echo form_open()?>
                                        <div class="myCard">
                                            <?php
                                                $id = $this->uri->segment(3);
                                                $query = $this->db->query("SELECT * FROM `users` WHERE `id` = '$id' ");
                                                $result = $query->result();
                                                foreach($result AS $row){
                                            ?>
                                                <p><b>Name:</b> <?php echo $row->user_name?></p>
                                                <p><b>Distribution_house:</b> <?php echo $row->distribution_house?></p>
                                                <input type="hidden"  name="id" value="<?php echo $row->id?>">
                                            <?php }?>
                                        </div>

                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="password" name="pass" required="required" class="form-control">
                                            </div>

                                             <div class="form-group">
                                                <label>Confirm Password</label>
                                                <input type="password" name="cpass" required="required" class="form-control">
                                            </div>
                                            
                                            <div class="form-group">
                                                <button type="submit" name="submit" class="btn btn-success">Change</button>
                                            </div>
                                    <?php echo form_close()?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>