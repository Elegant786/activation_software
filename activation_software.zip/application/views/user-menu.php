<li>
	<a href="#" class="has-arrow" aria-expanded="false">
		<span class="has-icon">
			<i class="icon-beaker"></i>
		</span>
		<span class="nav-title">Requests(User)</span>
	</a>
	<ul aria-expanded="false">
		<li>
			<a href='<?php echo base_url()?>dashboard/new-request'> <i class='icon-beaker'></i> &nbsp New Request</a>												
		</li>						
		<li>
			<a href='<?php echo base_url()?>dashboard/my-request'> <i class='icon-beaker'></i> &nbsp My Request</a>
		</li>

		<li>
			<a href='<?php echo base_url()?>dashboard/user-search'> <i class='icon-beaker'></i> &nbsp Search</a>
		</li>					
	</ul>
</li>