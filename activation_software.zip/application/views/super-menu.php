									<li>
										<a href="<?php echo base_url()?>dashboard/super-admin-search">
											<span class="has-icon">
												<i class="icon-flash-outline"></i>
											</span>
											<span class="nav-title">Search Request</span>
										</a>
									</li>

								<!-- Usermanagement Start-->
									<li>
										<a href="#" class="has-arrow" aria-expanded="false">
											<span class="has-icon">
												<i class="fa fa-user-plus"></i>
											</span>
											<span class="nav-title">User Management</span>
										</a>
										<ul aria-expanded="false">
											<li>
												<a href='<?php echo base_url()?>dashboard/users'>Users</a>
											</li>

											<li>
												<a href='<?php echo base_url()?>dashboard/admin'>Admins</a>
											</li>

											<li>
												<a href='<?php echo base_url()?>dashboard/super'>Super Admin</a>
											</li>
											
										</ul>
								</li>

								<!-- settings -->
								<li>
									<a href="#" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-cogs"></i>
										</span>
										<span class="nav-title">Settings</span>
									</a>
									<ul aria-expanded="false">
										<li>
											<a href='<?php echo base_url()?>dashboard/activition-team'> <i class="fa fa-user-plus"></i>&nbsp Activition Team</a>
										</li>

										<li>
											<a href='<?php echo base_url()?>dashboard/settings/serviecs'><i class="fa fa-scribd"></i> &nbsp Services</a>
										</li>

										<li>
											<a href='<?php echo base_url()?>dashboard/settings/products'> <i class="fa fa-product-hunt"></i> &nbsp Products</a>
										</li>

										<li>
											<a href='<?php echo base_url()?>dashboard/settings/distribution-house'> <i class="fa fa-product-hunt"></i> &nbsp Distribution House</a>
										</li>

										<li>
											<a href='<?php echo base_url()?>dashboard/settings/status'> <i class="fa fa-product-hunt"></i> &nbsp Status</a>
										</li>
										
									</ul>
								</li>
								<!-- settings End -->
