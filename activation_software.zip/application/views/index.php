<!doctype html>
<html lang="en">
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="author" content="Elegant Tech" />
		<link rel="shortcut icon" href="<?php echo base_url()?>assets/assets/img/favicon.ico" />
		<title><?php if(isset($title)) echo $title;else echo "Dashboard";?></title>

		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
		
		<!-- Common CSS -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/fonts/icomoon/icomoon.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/main.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/select2.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/font-awesome.min.css">
		<!-- Other CSS includes plugins - Cleanedup unnecessary CSS -->
		<!-- Chartist css -->
		<link href="<?php echo base_url()?>assets/assets/vendor/chartist/css/chartist.min.css" rel="stylesheet" />
		<link href="<?php echo base_url()?>assets/assets/vendor/chartist/css/chartist-custom.css" rel="stylesheet" />

		<!-- Data Tables -->
		<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/vendor/datatables/dataTables.bs4.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/vendor/datatables/dataTables.bs4-custom.css" />
    	<link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/style.css" />
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


	</head>
	<body>

		<!-- Loading 
		<?php if($this->uri->segment(2)==NULL){?>
		<div id="loading-wrapper">
			<div id="loader">
				<div class="line1"></div>
				<div class="line2"></div>
				<div class="line3"></div>
				<div class="line4"></div>
				<div class="line5"></div>
				<div class="line6"></div>
			</div>
		</div>
		<?php }?>
		s -->
		
		<!-- BEGIN .app-wrap -->
		<div class="app-wrap">
			<!-- BEGIN .app-heading -->
			<header class="app-header">
				<div class="container-fluid">
					<div class="row gutters">
						<div class="col-xl-5 col-lg-5 col-md-5 col-sm-3 col-4">
							<a class="mini-nav-btn" href="#" id="app-side-mini-toggler">
								<i class="icon-menu5"></i>
							</a>
							<a href="#app-side" data-toggle="onoffcanvas" class="onoffcanvas-toggler" aria-expanded="true">
								<i class="icon-chevron-thin-left"></i>
							</a>
						</div>
						<div class="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-4">
							<a href="index.html" class="logo">
								<img src="<?php echo base_url()?>assets/assets/img/unify.png" alt="Elegant Technology " />
							</a>
						</div>
						<div class="col-xl-5 col-lg-5 col-md-5 col-sm-3 col-4">
							<ul class="header-actions">
								
							<!-- Notification Start -->
								<li class="dropdown">
									<a href="#" id="notifications" data-toggle="dropdown" aria-haspopup="true">
										<i class="icon-notifications_none"></i>
										<span class="count-label"></span>
									</a>
									<div class="dropdown-menu dropdown-menu-right lg" aria-labelledby="notifications">
										<ul class="imp-notify">
											<li>
												<div class="icon">W</div>
												<div class="details">
													<p><span>Wilson</span> The best Dashboard design I have seen ever.</p>
												</div>
											</li>
											<li>
												<div class="icon">J</div>
												<div class="details">
													<p><span>John Smith</span> Jhonny sent you a message. Read now!</p>
												</div>
											</li>
											<li>
												<div class="icon secondary">R</div>
												<div class="details">
													<p><span>Justin Mezzell</span> Stella, Added you as a Friend. Accept it!</p>
												</div>
											</li>
										</ul>
									</div>
								</li> 
								

								<!-- Notification End -->

								<li class="dropdown">
									<a href="#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
										<img class="avatar" src="<?php echo base_url()?>assets/assets/img/user.png" alt="User Thumb" />
										<span class="user-name"><?php echo $this->session->userdata('username')?></span>
										<i class="icon-chevron-small-down"></i>
									</a>
									<div class="dropdown-menu lg dropdown-menu-right" aria-labelledby="userSettings">
										<ul class="user-settings-list">
											<li>
												<a href="<?php echo base_url()?>dashboard/profile/<?php echo $this->session->userdata('uid')?>">
													<div class="icon">
														<i class="icon-account_circle"></i>
													</div>
													<p>Profile</p>
												</a>
											</li>
											<li>
												<a href="<?php echo base_url()?>dashboard/change-password">
													<div class="icon red">
														<i class="icon-cog3"></i>
													</div>
													<p>Settings</p>
												</a>
											</li>
											<li>
												<a href="filters.html">
													<div class="icon yellow">
														<i class="icon-schedule"></i>
													</div>
													<p>Activity</p>
												</a>
											</li>
										</ul>
										<div class="logout-btn">
											<a href="<?php echo base_url()?>logout" class="btn btn-primary">Logout</a>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</header>
			<!-- END: .app-heading -->
			<!-- BEGIN .app-container -->
			<div class="app-container">
				<!-- BEGIN .app-side -->
				<aside class="app-side" id="app-side">
					<!-- BEGIN .side-content -->
					<div class="side-content ">
						<!-- BEGIN .user-profile -->
						<div class="user-profile">
							<img src="<?php echo base_url()?>assets/assets/img/user.png" class="profile-thumb" alt="User Thumb">
							<h6 class="profile-name"><?php echo $this->session->userdata('user_name')?></h6>
								<ul class="profile-actions">
									<li>
										<a href="<?php echo base_url()?>dashboard/profile/<?php echo $this->session->userdata('uid')?>">
											<i class="icon-user"></i>
											<span class="count-label red"></span>
										</a>
									</li>
									<li>
										<a href="<?php echo base_url()?>dashboard/change-password">
											<i class="icon-cogs"></i>
										</a>
									</li>
									<li>
										<a href="<?php echo base_url()?>logout">
											<i class="fa fa-sign-out"></i>
										</a>
									</li>
								</ul>
						</div>
						<!-- END .user-profile -->
						<!-- BEGIN .side-nav -->
						<nav class="side-nav">
							<!-- BEGIN: side-nav-content -->
							<ul class="unifyMenu" id="unifyMenu">
								<li class="active selected">
									<a href="<?php echo base_url()?>dashboard"  aria-expanded="false">
										<span class="has-icon">
											<i class="icon-dashboard"></i>
										</span>
										<span class="nav-title">Dashboards</span>
									</a>
								</li>

									<?php
										$level = $this->session->userdata('user_role');
										if($level==1){
											$this->load->view('super-menu');
										}elseif($level==2){
											$this->load->view('admin-menu');
										}else{
											$this->load->view('user-menu');
										}
									?>

								<!-- Usermanagement End -->

								



<!--

								<li>
									<a href="widgets.html">
										<span class="has-icon">
											<i class="icon-flash-outline"></i>
										</span>
										<span class="nav-title">Graph Widgets</span>
									</a>
								</li>
								
								<li>
									<a href="#" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-beaker"></i>
										</span>
										<span class="nav-title">UI Elements</span>
									</a>
									<ul aria-expanded="false">
										<li>
											<a href='general-elements.html'>General Elements</a>
										</li>
										
									</ul>
								</li>
-->
								<li class="menu-header">
									-- Layout Options
								</li>
								
								
								
								


							</ul>
							<!-- END: side-nav-content -->
						</nav>
						<!-- END: .side-nav -->
					</div>
					<!-- END: .side-content -->
				</aside>
				<!-- END: .app-side -->

				<?php
					if(isset($page)){
						$this->load->view('page/'.$page);
					}
				
				?>
				<!-- END: .app-main -->
			</div>
			<!-- END: .app-container -->
			<!-- BEGIN .main-footer -->
			<footer class="main-footer fixed-btm">
				Copyright <a target="_blank" href="https://www.eleganttechbd.com">Elegent Technology</a> <?php echo date("Y")?>.
			</footer>
			<!-- END: .main-footer -->
		</div>
		<!-- END: .app-wrap -->

		<!-- jQuery first, then Tether, then other JS. -->
		<script src="<?php echo base_url()?>assets/assets/js/jquery.js"></script>
		<script src="<?php echo base_url()?>assets/assets/js/tether.min.js"></script>
		<script src="<?php echo base_url()?>assets/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url()?>assets/assets/vendor/unifyMenu/unifyMenu.js"></script>
		<script src="<?php echo base_url()?>assets/assets/vendor/onoffcanvas/onoffcanvas.js"></script>
		<script src="<?php echo base_url()?>assets/assets/js/moment.js"></script>

		<!-- Slimscroll JS -->
		<script src="<?php echo base_url()?>assets/assets/vendor/slimscroll/slimscroll.min.js"></script>
		<script src="<?php echo base_url()?>assets/assets/vendor/slimscroll/custom-scrollbar.js"></script>

		<!-- Chartist JS
			<script src="<?php echo base_url()?>assets/assets/vendor/chartist/js/chartist.min.js"></script>
			<script src="<?php echo base_url()?>assets/assets/vendor/chartist/js/chartist-tooltip.js"></script>
			<script src="<?php echo base_url()?>assets/assets/vendor/chartist/js/custom/custom-line-chart.js"></script>
			<script src="<?php echo base_url()?>assets/assets/vendor/chartist/js/custom/custom-line-chart1.js"></script>
			<script src="<?php echo base_url()?>assets/assets/vendor/chartist/js/custom/custom-pie-charts.js"></script>
		 -->
		<!-- 
			<script src="<?php echo base_url()?>assets/assets/vendor/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
			<script src="<?php echo base_url()?>assets/assets/vendor/jvectormap/world-mill-en.js"></script>
			<script src="<?php echo base_url()?>assets/assets/vendor/jvectormap/gdp-data.js"></script>
		JVector Maps -->
		<!-- Custom JVector Maps -->
		<script src="<?php echo base_url()?>assets/assets/vendor/jvectormap/custom/world-map-markers.js"></script>

		<!-- Data Tables -->
		<script src="<?php echo base_url()?>assets/assets/vendor/datatables/dataTables.min.js"></script>
		<script src="<?php echo base_url()?>assets/assets/vendor/datatables/dataTables.bootstrap.min.js"></script>
		
		<!-- Custom Data tables -->
		<script src="<?php echo base_url()?>assets/assets/vendor/datatables/custom/custom-datatables.js"></script>
		<script src="<?php echo base_url()?>assets/assets/vendor/datatables/custom/fixedHeader.js"></script>

		<!-- Common JS -->
		<script src="<?php echo base_url()?>assets/assets/js/common.js"></script>
		<script src="<?php echo base_url()?>assets/assets/js/select2.js"></script>
			<!-- Select 2 -->
		<script type="text/javascript">
			$(document).ready(function() {
			    $('.select2').select2();
			});
		</script>
		
		<?php
			if(isset($_GET['action']) && $_GET['action']=='success'){

		?>
			<script type="text/javascript">
			    $(window).on('load',function(){
			        $('#myModal').modal('show');
			    });
			    $("p").click(function(){
				     $('#myModal').modal('hide');
				});
				$('.close').on('click',function(){
					$(document).find('.modal-backdrop').hide();
					$(document).find('.modal').hide();
				});
				
			</script>
		<?php }?>

	</body>

</html>