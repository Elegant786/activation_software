
									<li>
										<a href="#" class="has-arrow" aria-expanded="false">
											<span class="has-icon">
												<i class="icon-beaker"></i>
											</span>
											<span class="nav-title">Requests(Admin)</span>
										</a>
										<ul aria-expanded="false">
											<li>
												<a href='<?php echo base_url()?>dashboard/admin-open-request'> <i class='icon-beaker'></i> &nbsp View Requests
												</a>												
											</li>	
										
											<li>
												<a href='<?php echo base_url()?>dashboard/admin-search'> <i class='icon-beaker'></i> &nbsp Search Request
												</a>
											</li>										
									  </ul>
									</li>