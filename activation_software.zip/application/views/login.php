<!doctype html>
<html lang="en">
<head>		
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Elegant Technology" />
    <link rel="shortcut icon" href="<?php echo base_url()?>assets/assets/img/favicon.ico" />
    <title>Ticket Activition</title>		
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">		
    <link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>assets/assets/fonts/icomoon/icomoon.css" />		
    <link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/main.css" />
    <link rel="stylesheet" href="<?php echo base_url()?>assets/assets/css/style.css" />
</head>  

	<body class="login-bg">
			
		<div class="container">
                <div class="row top-margin-20">
                    <div class="col-md-12">
                        <?php
                            if(validation_errors()){
                                echo "<div class='alert bg-warning'>".validation_errors()."</div>";
                            }

                            if(isset($_GET['login']) && $_GET['login'] == 'error' ){
                                echo "<div class='alert bg-danger'>Email or Password Not Match</div>";
                            }
                            if(isset($_GET['login']) && $_GET['login'] == 'no-session' ){
                                echo "<div class='alert bg-danger'>Your Last session was expired</div>";
                            }
                            if(isset($_GET['login']) && $_GET['login'] == 'logout' ){
                                echo "<div class='alert bg-success'>Thank you for using me :)</div>";
                            }
                        ?>
                    </div>
                </div>
			<div class="login-screen row align-items-center">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
					<?php echo form_open('login')?>
						<div class="login-container">
							<div class="row no-gutters">
								<div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
									<div class="login-box">
										<a href="#" class="login-logo">
											<img src="<?php echo base_url()?>assets/assets/img/unify.png" alt="Unify Admin Dashboard" />
										</a>
										<div class="input-group">
											<span class="input-group-addon" id="username"><i class="icon-account_circle"></i></span>
											<input type="text" name="email" class="form-control" placeholder="Your Email  Address" aria-label="username" aria-describedby="username">
										</div>
										<br>
										<div class="input-group">
											<span class="input-group-addon" id="password"><i class="icon-verified_user"></i></span>
											<input name="password" type="password" class="form-control" placeholder="Your Password" aria-label="Password" aria-describedby="password">
										</div>
										<div class="actions clearfix">
											<a href="forgot-pwd.html">Lost password?</a>
											<button type="submit" class="btn btn-primary">Login</button>
										</div>
										
										
									</div>
								</div>
								<div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
									<div class="login-slider"></div>
								</div>
							</div>
						</div>
					<?php echo form_close()?>
				</div>
			</div>
		</div>
		<footer class="main-footer no-bdr fixed-btm">
			<div class="container">
				Copyright <a target="_blank" href="https://eleganttechbd.com">Elegant Technology</a> <?php echo date("Y")?>.
			</div>
		</footer>
	</body>
</html>