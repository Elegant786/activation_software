<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		//Load Model Here
		$this->load->model('UserModel');

		//Load helper
		$this->load->helper('security');
		//Load Library
		$this->load->library('pagination');
	} 

	public function ValidPage(){
		if($this->UserModel->CheckLogin()==FALSE){
			redirect('login','refresh');
		}else{

		}
	}
	
	/****************************
		===  Login Page
	*****************************/

	public function index(){
		if($this->UserModel->CheckLogin()==TRUE){
			redirect('dashboard','refresh');
		}else{
			$this->load->view('login');
		}

	}


	/****************************
		===  Login Functions
	*****************************/

	public function Login(){
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');			
		$this->form_validation->set_rules('password', 'Password', 'trim|required');		

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('login');
		}else{			
			if($this->UserModel->Login()==TRUE){				
				redirect('dashboard','refresh');
			}else{
				redirect('user-login?login=error','refresh');
			}
		}
	}

	//Logout

	public function Logout(){
		$this->session->unset_userdata("user_name");
		$this->session->unset_userdata("password");
		$this->session->unset_userdata("email");
		$this->session->unset_userdata("distribution_house");
		$this->session->unset_userdata("service_id");
		$this->session->unset_userdata("user_role");
		$this->session->unset_userdata("user_id");
		$this->session->unset_userdata("uid");
		$this->session->sess_destroy();
		redirect('user-login?login=logout','refresh');
	}

	/****************************
		===  All Users ===
	*****************************/

	//All users
	public function  AllUsers(){


		$this->ValidPage();


		$num =$this->UserModel->CountUsers();
            $config=array(

                    'base_url'           =>     base_url('dashboard/users'),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->UserModel->GetUsers($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'users','users' => $result,'title' => 'Dashobard | Users');
        $this->load->view('index',$data);
	}

	//UserDelete

	public function UserRemove(){


		$this->ValidPage();

		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM `users` WHERE `id` = '$id'");
		redirect('dashboard/users','refresh');
	}
	//Single user View
	public function UserView(){
		$id = $this->uri->segment(3);
		$result = $this->UserModel->GetUser($id);
		$attr = array(
			'page'  => 'user-details',
			'user'  => $result
		);
		$this->load->view('index',$attr);
	}
/***********************************************************************
					=== Admins Functions
 ***********************************************************************/
	public function AllAdmins(){

		$this->ValidPage();

		$num =$this->UserModel->CountAdmins();
	            $config=array(

	                    'base_url'           =>     base_url('dashboard/admin'),
	                    'per_page'           =>     15,
	                    'total_rows'         =>     $num,
	                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
	                    'full_tag_close'     =>     '</ul>',
	                    'first_tag_open'     =>     '<li>',
	                    'first_tag_close'    =>     '</li>',
	                    'last_tag_open'      =>     '<li>',
	                    'last_tag_close'     =>     '</li>',
	                    'next_tag_open'      =>     '<li>',
	                    'next_tag_close'     =>     '</li>', 
	                    'prev_tag_open'      =>     '<li>',
	                    'prev_tag_close'     =>     '</li>',
	                    'num_tag_open'       =>     '<li>',
	                    'num_tag_close'      =>     '</li>',
	                    'cur_tag_open'       =>     '<li class="active"> <a>',
	                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->UserModel->GetAdmins($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'admins','users' => $result,'title' => 'Dashobard | Users');
        $this->load->view('index',$data);
	}

   public function AdminRemove(){

   	$this->ValidPage();

   		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM `users` WHERE `id` = '$id'");
		redirect('dashboard/admin','refresh');
   }

   public function AdminView(){

   	$this->ValidPage();

   		$id = $this->uri->segment(3);
		$result = $this->UserModel->GetUser($id);
		$attr = array(
			'page'  => 'admin-details',
			'user'  => $result
		);
		$this->load->view('index',$attr);
   }


 /*****************************************************************************************
 					=========== AllSuperAdmin =============
 *****************************************************************************************/
 	public function AllSuperAdmin(){

 		$this->ValidPage();

		$num =$this->UserModel->CountSuperAdmin();
	            $config=array(

	                    'base_url'           =>     base_url('dashboard/super'),
	                    'per_page'           =>     15,
	                    'total_rows'         =>     $num,
	                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
	                    'full_tag_close'     =>     '</ul>',
	                    'first_tag_open'     =>     '<li>',
	                    'first_tag_close'    =>     '</li>',
	                    'last_tag_open'      =>     '<li>',
	                    'last_tag_close'     =>     '</li>',
	                    'next_tag_open'      =>     '<li>',
	                    'next_tag_close'     =>     '</li>', 
	                    'prev_tag_open'      =>     '<li>',
	                    'prev_tag_close'     =>     '</li>',
	                    'num_tag_open'       =>     '<li>',
	                    'num_tag_close'      =>     '</li>',
	                    'cur_tag_open'       =>     '<li class="active"> <a>',
	                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->UserModel->GetSuperAdmins($config['per_page'], $this->uri->segment(3));
        $data = array('page' => 'super-admins','users' => $result,'title' => 'Dashobard | Users');
        $this->load->view('index',$data);
	}
/************************************************************************
							Profile
************************************************************************/

	public function Profile(){

		$this->ValidPage();

		$user_id = $this->uri->segment(3);
		$result = $this->UserModel->Profile($user_id);
		$data = array('page' => "user-profile", 'user' => $result);
		$this->load->view('index',$data);
	}
//Change User Password
	public function ChangePassword(){
		$this->ValidPage();
		$data = array(
			'page' => 'change_password',
			'title' => 'Change Password'
		);
		$this->load->view('index',$data);
	}

	public function AdminChangePass(){
		$this->ValidPage();
		$data = array(
			"page" => "admin_password",
			"title" => "change Password"
		);	
		$this->load->view('index',$data);
	}


	public function AdminByteam(){
		$this->ValidPage();
		$active  = $this->uri->segment(3);
		$result = $this->UserModel->AdminByteam($active);
		$data = array('users' => $result);
		$this->load->view('page/admin_byTeam',$data);
	}

/************************************************************************
							Requets Management
************************************************************************/


#End Of File
}

/* End of file UserController.php */
/* Location: ./application/controllers/UserController.php */