<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/***********************************************************************************************************************
	@All Dashboards Functionality hear

*/



class DashboardController extends CI_Controller {
	public function __construct(){
		parent::__construct();
		//Loading Models
		$this->load->model("UserModel");
		$this->load->model('DashboardModel');
		//Load Library
		$this->load->library('pagination');		
		//Loading Helpers
		$this->load->helper('security');
		$this->load->helper('download');
		if($this->UserModel->CheckLogin()==FALSE){
			redirect('user-login','refresh');
		}
	}

//Index
	public function index(){
		
		if($this->session->userdata('user_role')==1){
			$data['page'] = "super-dash";
		}elseif($this->session->userdata('user_role')==2){
			$data['page'] = "admin-dash";
		}else{
			$data['page'] = "user-dash";
		}
		$data['title'] = "Dashboard | Home";
		
		$this->load->view('index',$data);

	}



/*******************  Activition Team Start ************************/
	//Add new Activition Team

	public function ActivitionTeam(){
		$data = array(
				'page' => 'activition-team',
				'title' => "Dashboard | Activition Team"
			);
			$this->load->view('index',$data);
	}
	//Edit Team
	public function EditTeam(){
		$data = array(
				'page' => 'activition-team',
				'title' => "Dashboard | Edit Activition Team"
			);
			$this->load->view('index',$data);
	}
	//Delete Team
	public function TeamDelete(){
		$id = $this->uri->segment(4);
		$this->db->where('team_id',$id);
		$this->db->delete('activition_team');
		redirect('dashboard/activition-team','refresh');
	}
/******************* Activition Team End **********************/




/************* Service Start ****************/
	//add service
	public function Services(){
		$data = array(
			'page' => 'services',
			'title' => "Dashboard | Services"
		);
	   $this->load->view('index',$data);
	}
	//Update service
	public function EditServices(){
		$data = array(
			'page' => 'services',
			'title' => "Dashboard | Edit Services"
		);
	   $this->load->view('index',$data);
	}
	//Delete service
	public function DeleteService(){
		$id = $this->uri->segment(4);
		$this->db->where('ser_id',$id);
		$this->db->delete('services');
		redirect('dashboard/settings/serviecs','refresh');
	}
/************ Service End *************/



/************  Products Start   *********/
	//Products Insert
	public function NewProducts(){
		$data = array(
			'page' => 'products',
			'title' => "Dashboard | Products "
		);
	   $this->load->view('index',$data);
	}
	//Products Delete
	public function ProDelete(){
			$id = $this->uri->segment(3);
			$this->db->where('pro_id',$id);
			$this->db->delete('products');
			redirect('dashboard/settings/products?delete=success','refresh'); 
	}
	//Product Edit
	public function ProEdit(){
		$data = array(
			'page' => 'products',
			'title' => "Dashboard | Products "
		);
	   $this->load->view('index',$data);
	}

/*************  Products End  ************/


/************************************
		========DistributionHouse======
***************************************/

	public function DistributionHouse(){

		$data = array(
			"page"   => "distri-house",
			"title"  => "Distribution House Setting"
		);
		$this->load->view('index',$data);

	}

	public function DeleteDistributionHouse(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM `distributuion` WHERE `dis_id` = '$id' ");
		redirect('dashboard/settings/distribution-house','refresh');
	}


/***********************************************************
				===	RequestStatus ===
***********************************************************/
	public function RequestStatus(){
		$data = array(
			'page' => 'status',
			'title' => "Dashboard | Status "
		);
	   $this->load->view('index',$data);
	}

	public function AddStatus(){

		$config=array(
	      'upload_path'   =>  'uploads/request'  ,
	      'allowed_types' =>  'gif|jpg|png|PNG|JPEG|GIF|PNG|JPG|jpeg',
	      'overwrite'     =>  TRUE,
	      'encrypt_name'  =>   TRUE,
	      'max_size'      =>  "10000"
	      );

	    $this->load->library('upload', $config);
	    
	     if ( ! $this->upload->do_upload('image')){
	                $data['upload_error']=$this->upload->display_errors(); 
	                $data['page'] = "post";
					$this->load->view('dashboard/new-request',$data);
	        }else{
	        	if($this->DashboardModel->AddStatus()==TRUE){
	        		redirect('dashboard/settings/status?action=success','refresh');
	        	}else{
	        		redirect('dashboard/settings/status?action=failed','refresh');	        		
	        	}
	        }

	}

	public function RemoveStatus(){
		$id = $this->uri->segment(3);
		$query = $this->db->query("DELETE FROM  `status` WHERE `sta_id` = '$id' ");
		redirect('dashboard/settings/status','refresh');
	}

/************************************************************
					====Request Star====
*************************************************************/

	public function NewRequest(){
		$data = array(
			"page"	=> 'new-request',
			'title' => 'New Request'
		);
		$this->load->view('index',$data);
	}

	/***********************************************
					GEtServices Ajax Request
	************************************************/
	public function GerSrevices(){
		echo "<option value='0'>Select One</option>";
		$ser = $this->uri->segment(3);
		$query = $this->db->query("SELECT * FROM `services` WHERE `team_id` = '$ser' ");
		$result = $query->result();
		foreach($result AS $row){
			echo "<option value='{$row->ser_id}'>{$row->service_name}</option>";
		}
	}

	/*******************************
		============GetProducts Ajax Request========
	***********************************/

	public  function GetProducts(){
		echo "<option value='0'>Select One</option>";
		$pro = $this->uri->segment(3);
		$query = $this->db->query("SELECT * FROM `products` WHERE `ser_id` = '$pro' ");
		$result = $query->result();
		foreach($result AS $row){
			echo "<option value='{$row->pro_id}'>{$row->pro_name}</option>";
		}
	}

	/*********************************  Function SendMail    **********************************/

	public function sendEmail(){
			$email = $_GET['to'];
			$subject = $_GET['subject'];
			$message = $_GET['message'];
			$attach = isset($_GET['attach']) ? $_GET['attach']:NULL;

		    $config = Array(
		      'protocol'    => 'smtp',
		      'smtp_host'   => 'ssl://smtp.googlemail.com',
		      'smtp_port'   => 465,
		      'smtp_user'   => 'webreciter@gmail.com', 
		      'smtp_pass'   => 'Rahaman++', 
		      'mailtype'    => 'html',
		      'charset' 	=> 'iso-8859-1',
		      'wordwrap'    => TRUE
		    );
          $this->load->library('email', $config);
          $this->email->set_newline("\r\n");
          $this->email->from('webreciter@@gmail.com');
          $this->email->to($email);
          $this->email->subject($subject);

          $this->email->message($message);
          if($attach!=NULL){
        	  $this->email->attach($attach);
      		}
          if($this->email->send()){
        		return TRUE;
         	}
         else{
        	 show_error($this->email->print_debugger());
        	}
    }
    /***************************************************
				==========Make Request=================
    ****************************************************/
    public function MakeRequets(){
    	
    	if($_FILES['image']['size']==0){
    		if($this->DashboardModel->MakeRequst()==TRUE){
        		redirect('dashboard/new-request?action=success','refresh');
        	}else{
        		redirect('dashboard/new-request?action=failed','refresh');	        		
        	}
    	}else{
    		//If Have File
    	$config=array(
	      'upload_path'   =>  'uploads/request'  ,
	      'allowed_types' =>  'gif|jpg|png|PNG|JPEG|GIF|doc|docx|PDF|pdf|txt|TXT|ZIP|zip|RAR|rar|tar|TAR|xlsx|XLSX|xlsm|XLSM|xltx|XLTX|xltm|XLTM|rtf|RTF',
	      'overwrite'     =>  TRUE,
	      'encrypt_name'  =>   TRUE,
	      'max_size'      =>  "10000"
	      );

	    $this->load->library('upload', $config);
	    
	     if ( ! $this->upload->do_upload('image')){
	                $data['upload_error']=$this->upload->display_errors(); 
	                $data['page'] = "post";
					$this->load->view('dashboard/new-request',$data);
	        }else{
	        	if($this->DashboardModel->MakeRequst()==TRUE){
	        		redirect('dashboard/new-request?action=success','refresh');
	        	}else{
	        		redirect('dashboard/new-request?action=failed','refresh');	        		
	        	}
	        }
	   }


    }


    /*****************************************************************
						+++++++++++Show Recent Request++++++++++++++
    ******************************************************************/
    public function MyRequestUser(){

    	$num =$this->DashboardModel->CountMyRequetsUser();
            $config=array(

                    'base_url'           =>     base_url('dashboard/my-request'),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetMyRequestUser($config['per_page'], $this->uri->segment(3));


    	$attr = array(
    		'page'  => 'user-requests',
    		'title' => 'My Request',
    		'request' => $result
    	);
    	$this->load->view('index',$attr);
    }
    /*************************************************************************************/
    /************************************Single View Of Request***************************/
    /*************************************************************************************/

    public function ViewRequest(){
    	$data =array(
    		"page" => 'view-request-user',
    		'title' => "View Request"  		
    	);
     $this->load->view('index',$data);
    }
    /*******************************************************************************************/    
    /************************************ViewByStatus User**************************************/
    /*******************************************************************************************/
    public function ViewByStatus(){
    	$status = $this->uri->segment(4);
    	$num =$this->DashboardModel->CountByStatusUser($status);
            $config=array(

                    'base_url'           =>     base_url('dashboard/view/by-status/'.$this->uri->segment(4)),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetRequestByStatus($config['per_page'], $this->uri->segment(5),$this->uri->segment(4));
        $data = array(
        	"request" =>$result,
        	"page" 	  => "user-requests",
        	"title"   => "Dashboard | Requests By Status"
        );
        $this->load->view("index",$data);


    }
    /*********************************************************************************/    
    /*********************************Download File************************************/
    /*********************************************************************************/

    public function DownloadFile(){
    	$file = $this->uri->segment(2);
    	force_download("uploads/request/".$file, NULL);
    }



    /*********************************
			AdminRecent Requests
    ********************************/
	public function AdminOpenRequest(){

		$num =$this->DashboardModel->CountAdminOpen();
            $config=array(

                    'base_url'           =>     base_url('dashboard/users'),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetAdminOpenReq($config['per_page'], $this->uri->segment(3));
        $data = array(
        	'page' 		=> "admin-open-request",
        	'title' 	=> "Open Requests",
        	'request'	=> $result
        );
        $this->load->view('index',$data);

	}

	/***************************************
			View By Status Admin
	*******************************************/

	public function ViewByStatusAdmin(){
    	$status = $this->uri->segment(4);
    	$num =$this->DashboardModel->CountByStatusAdmin($status);
            $config=array(

                    'base_url'           =>     base_url('dashboard/view-admin/by-status/'.$this->uri->segment(4)),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetRequestByAdmin($config['per_page'], $this->uri->segment(5),$this->uri->segment(4));
        $data = array(
        	"request" =>$result,
        	"page" 	  => "admin-open-request",
        	"title"   => "Dashboard | Requests By Status"
        );
        $this->load->view("index",$data);


    }
/*************************************************
		=========Execution Start Now============
****************************************************/
	public function Execute(){
		$re_direct = $this->input->post('req_id');
		if($_FILES['image']['size']==0){
				if($this->DashboardModel->DoExecute()==TRUE){
					redirect('dashboard/view-request/'.$re_direct.'?action=success','refresh');
				}else{
					redirect('dashboard/view-request/'.$re_direct.'?action=failed','refresh');	
				}
		}else{
		//If Have File
    	$config=array(
	      'upload_path'   =>  'uploads/request'  ,
	      'allowed_types' =>  'gif|jpg|png|PNG|JPEG|GIF|doc|docx|PDF|pdf|txt|TXT|ZIP|zip|RAR|rar|tar|TAR|xlsx|XLSX|xlsm|XLSM|xltx|XLTX|xltm|XLTM|rtf|RTF',
	      'overwrite'     =>  TRUE,
	      'encrypt_name'  =>   TRUE,
	      'max_size'      =>  "10000"
	      );

	    $this->load->library('upload', $config);
	    
	     if ( ! $this->upload->do_upload('image')){
	                $data['upload_error']=$this->upload->display_errors(); 
	                $data['page'] = "view-request-user";
					$this->load->view('dashboard/new-request',$data);
	        }else{
	        	if($this->DashboardModel->DoExecute()==TRUE){
	        		redirect('dashboard/view-request/'.$re_direct.'?action=success','refresh');
	        	}else{
	        		redirect('dashboard/view-request/'.$re_direct.'?action=failed','refresh');	        		
	        	}
	        }

		}
	}
/**********************************
		Search Function for users
************************************/
	public function UserSearch(){
		$data = array(
			"page" => 'user-search',
			'title' => "User Search"

		);
		$this->load->view('index',$data);
	}
/**********************************
		Search Function for Admin
************************************/
	public function AdminSearch(){		
		$data = array(
			"page" => "admin-search",
			'title' => "Dashboard | Admin search"
		);
	  $this->load->view('index',$data);
	}




/*******************************************************
		========= Search Page For Super Admin ================
**********************************************************/
	public function SuperSearch(){
		$data = array(
			"page" => "super-search",
			"title" => "Dashboard | Super Admin Search"
		);
		$this->load->view("index",$data);
	}

/************************************************
	========== View By Status For Super Admin 
************************************************/
	public function ViewBSuper(){
		$status = $this->uri->segment(4);
    	$num =$this->DashboardModel->CountByStatusSuper($status);
            $config=array(

                    'base_url'           =>     base_url('dashbboard/view-super/by-status/'.$this->uri->segment(4)),
                    'per_page'           =>     15,
                    'total_rows'         =>     $num,
                    'full_tag_open'      =>     '<ul class="pagination pagination-sm no-margin pull-right">',
                    'full_tag_close'     =>     '</ul>',
                    'first_tag_open'     =>     '<li>',
                    'first_tag_close'    =>     '</li>',
                    'last_tag_open'      =>     '<li>',
                    'last_tag_close'     =>     '</li>',
                    'next_tag_open'      =>     '<li>',
                    'next_tag_close'     =>     '</li>', 
                    'prev_tag_open'      =>     '<li>',
                    'prev_tag_close'     =>     '</li>',
                    'num_tag_open'       =>     '<li>',
                    'num_tag_close'      =>     '</li>',
                    'cur_tag_open'       =>     '<li class="active"> <a>',
                    'cur_tag_close'      =>     '</a></li>'

                    );

            
        $this->pagination->initialize($config);
        $result=$this->DashboardModel->GetRequestBySuper($config['per_page'], $this->uri->segment(5),$this->uri->segment(4));
        $data = array(
        	"request" =>$result,
        	"page" 	  => "admin-open-request",
        	"title"   => "Dashboard | Requests By Status"
        );
        $this->load->view("index",$data);


	}

/****************************************
	====== GetActivitionMembers ========
*****************************************/
	public function GetActivitionMembers(){
		echo "<option value='0'>Select Please...</option>";
		$active = $this->uri->segment(3);
		if($active!=0){
			$query = $this->db->query("SELECT * FROM `users` WHERE `active_team` = '$active' ");
			$result = $query->result();
			foreach($result AS $row){
				echo "<option value='".$row->id."'>{$row->user_name}</option>";
			}
		}
	}




#End Of Class
}



/* End of file DashboardController.php */
/* Location: ./application/controllers/DashboardController.php */